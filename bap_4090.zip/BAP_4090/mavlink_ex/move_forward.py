import asyncio
import math
from mavsdk import System
from mavsdk.offboard import OffboardError, PositionNedYaw


async def move_in_heading(distance, heading_deg, direction="forward"):
    # Convert heading from degrees to radians
    heading_rad = math.radians(heading_deg)

    # Calculate NED movement based on direction and heading
    if direction == "forward":
        north = distance * math.cos(heading_rad)
        east = distance * math.sin(heading_rad)
    elif direction == "backward":
        north = -distance * math.cos(heading_rad)
        east = -distance * math.sin(heading_rad)
    elif direction == "left":
        north = distance * math.cos(heading_rad + math.pi / 2)
        east = distance * math.sin(heading_rad + math.pi / 2)
    elif direction == "right":
        north = distance * math.cos(heading_rad - math.pi / 2)
        east = distance * math.sin(heading_rad - math.pi / 2)
    else:
        raise ValueError(f"Unknown direction: {direction}")

    drone = System()
    await drone.connect(system_address="udp://:14540")

    print("Waiting for drone to connect...")
    async for state in drone.core.connection_state():
        if state.is_connected:
            print("Drone connected")
            break

    """# Arm the drone
    print("Arming drone...")
    await drone.action.arm()

    # Take off and reach a certain altitude
    print("Taking off...")
    await drone.action.takeoff()
    await asyncio.sleep(5)"""
    print("-- Setting initial setpoint")
    await drone.offboard.set_position_ned(PositionNedYaw(0.0, 0.0, 0.0, 0.0))

    print("-- Starting offboard")
    try:
        await drone.offboard.start()
    except OffboardError as error:
        print(f"Starting offboard mode failed \
                    with error code: {error._result.result}")
        print("-- Disarming")
        await drone.action.disarm()
        return

    # Move the drone based on calculated NED position
    print(f"Moving {direction} by {distance} meters (Heading: {heading_deg} degrees)...")
    await drone.offboard.set_position_ned(PositionNedYaw(north, east, 0.0, heading_deg))  # Keep altitude and yaw stable
    await asyncio.sleep(10)

    try:
        await drone.offboard.start()
        await asyncio.sleep(5)  # Allow the drone to move
        await drone.offboard.stop()
    except OffboardError as error:
        print(f"Offboard mode failed with error: {error._result.result}")

    await drone.offboard.set_position_ned(
        PositionNedYaw(0.0, 0.0, 0.0, 180.0))
    await asyncio.sleep(10)

    print("-- Stopping offboard")
    try:
        await drone.offboard.stop()
    except OffboardError as error:
        print(f"Stopping offboard mode failed \
                    with error code: {error._result.result}")

    """print("Landing...")
    await drone.action.land()"""

async def get_heading():
    # Connect to the drone
    drone = System()
    await drone.connect(system_address="udp://:14540")

    print("Waiting for drone to connect...")
    async for state in drone.core.connection_state():
        if state.is_connected:
            print("Drone connected")
            break

    # Subscribe to telemetry heading data
    async for position in drone.telemetry.heading():
        print(f"Current Heading: {position.heading_deg} degrees")
        # break  # Exit after one reading, or remove this to continuously get updates
        return position.heading_deg
heading_deg = asyncio.run(get_heading())

# Example usage
asyncio.run(move_in_heading(2.0, heading_deg, direction="forward"))  # Move 2 meters forward at 45 degrees heading
