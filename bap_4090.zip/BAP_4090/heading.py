import asyncio
from mavsdk import System

async def get_heading():
    # Connect to the drone
    drone = System()
    await drone.connect(system_address="udp://:14540")

    print("Waiting for drone to connect...")
    async for state in drone.core.connection_state():
        if state.is_connected:
            print("Drone connected")
            break

    # Subscribe to telemetry heading data
    async for position in drone.telemetry.heading():
        print(f"Current Heading: {position.heading_deg} degrees")
        break  # Exit after one reading, or remove this to continuously get updates

asyncio.run(get_heading())

