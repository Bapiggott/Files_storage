import asyncio
from mavsdk import System
from mavsdk.offboard import OffboardError, VelocityBodyYawspeed

async def move_forward_in_heading():
    drone = System()
    await drone.connect(system_address="udp://:14540")

    print("Waiting for drone to connect...")
    async for state in drone.core.connection_state():
        if state.is_connected:
            print("Drone connected")
            break

    # Arm the drone
    print("Arming drone...")
    await drone.action.arm()

    # Take off and reach a certain altitude
    print("Taking off...")
    await drone.action.takeoff()
    await asyncio.sleep(5)

    # Move the drone forward 2 meters in its current heading direction
    print("Moving forward by 2 meters in the current heading direction...")
    await drone.offboard.set_velocity_body(VelocityBodyYawspeed(1.0, 0.0, 0.0, 0))  # Move forward with 1 m/s velocity in body frame

    try:
        await drone.offboard.start()
        await asyncio.sleep(2)  # Move for 2 seconds (1 m/s * 2 seconds = 2 meters)
        await drone.offboard.stop()
    except OffboardError as error:
        print(f"Offboard mode failed with error: {error._result.result}")



asyncio.run(move_forward_in_heading())

