from functions import *
import asyncio

async def main():
	await turn_ccw(90)
	if iv('apple')==True and iv('orange'):
		log('Yes')
		return True
	log('No')
	return False
	if s('bottle')==True:
		await goto('bottle')
		_2 = object_height('bottle')
		log(_2)
		tp
asyncio.run(main())
