import gc
import yaml
import asyncio
import os
from threading import Lock

# NVidia API imports
import carb
import omni.kit.app
from omni.isaac.core.world import World
from omni.isaac.core.utils.stage import clear_stage, create_new_stage_async, update_stage_async, create_new_stage
from omni.isaac.core.utils.viewports import set_camera_view
import omni.isaac.nucleus as nucleus

# Pegasus Simulator internal API
from pegasus.simulator.params import DEFAULT_WORLD_SETTINGS, SIMULATION_ENVIRONMENTS, CONFIG_FILE
from pegasus.simulator.logic.vehicle_manager import VehicleManager

print(nucleus.get_assets_root_path())
