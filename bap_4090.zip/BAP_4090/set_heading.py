import asyncio
from mavsdk import System
from mavsdk.offboard import OffboardError, VelocityNedYaw

async def set_heading_with_velocity(yaw_deg):
    drone = System()
    await drone.connect(system_address="udp://:14540")

    print("Waiting for drone to connect...")
    async for state in drone.core.connection_state():
        if state.is_connected:
            print("Drone connected")
            break

    # Arm the drone
    print("Arming drone...")
    await drone.action.arm()

    # Set the offboard mode
    print("Setting offboard mode...")
    await drone.offboard.set_velocity_ned(VelocityNedYaw(0, 0, 0, yaw_deg))

    try:
        await drone.offboard.start()
        print(f"Rotating to {yaw_deg} degrees heading...")
        await asyncio.sleep(5)
        await drone.offboard.stop()
    except OffboardError as error:
        print(f"Offboard mode failed with error: {error._result.result}")

    

asyncio.run(set_heading_with_velocity(45))  # Example: Set heading to 90 degrees

