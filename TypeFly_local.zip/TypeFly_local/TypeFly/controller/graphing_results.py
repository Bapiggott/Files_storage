"""import json
import matplotlib.pyplot as plt

# Step 1: Load JSON data from a file
with open('results.json', 'r') as file:
    data = json.load(file)

# Step 2: Extract data
filenames = []
gpu_usages = []
time_taken = []

for filename, tasks in data.items():
    for task in tasks:
        filenames.append(filename)
        gpu_usages.append(task['gpu_usage'])
        time_taken.append(task['time_taken'])

# Step 3: Plot the data
fig, ax1 = plt.subplots()

# Plot GPU usage
ax1.set_xlabel('Filename')
ax1.set_ylabel('GPU Usage', color='tab:blue')
ax1.bar(filenames, gpu_usages, color='tab:blue', alpha=0.6, label='GPU Usage')
ax1.tick_params(axis='y', labelcolor='tab:blue')

# Create a second y-axis to plot time taken
ax2 = ax1.twinx()
ax2.set_ylabel('Time Taken (s)', color='tab:orange')
ax2.bar(filenames, time_taken, color='tab:orange', alpha=0.6, label='Time Taken')
ax2.tick_params(axis='y', labelcolor='tab:orange')

# Title and legend
plt.title('GPU Usage and Time Taken for Different Tasks')
fig.tight_layout()

# Show plot
plt.show()
"""
import json
import matplotlib.pyplot as plt

# Step 1: Load JSON data from a file
with open('results.json', 'r') as file:
    data = json.load(file)

# Step 2: Extract data
filenames = []
gpu_usages = []
time_taken = []
gpu_usage_dict = {}
time_taken_dict = {}

for filename, tasks in data.items():
    gpu_usage_dict[filename] = []
    time_taken_dict[filename] = []
    for task in tasks:
        filenames.append(filename)
        gpu_usages.append(task['gpu_usage'])
        time_taken.append(task['time_taken'])
        gpu_usage_dict[filename].append(task['gpu_usage'])
        time_taken_dict[filename].append(task['time_taken'])

# Prepare data for box plots
gpu_usage_data = [gpu_usage_dict[filename] for filename in gpu_usage_dict]
time_taken_data = [time_taken_dict[filename] for filename in time_taken_dict]
labels = list(gpu_usage_dict.keys())

# Step 3: Plot the box plots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 7))

# Box plots for GPU usage
ax1.boxplot(gpu_usage_data, patch_artist=True, labels=labels)
ax1.set_title('GPU Usage Distribution')
ax1.set_xlabel('Filename')
ax1.set_ylabel('GPU Usage')
ax1.tick_params(axis='x', rotation=45)

# Box plots for Time Taken
ax2.boxplot(time_taken_data, patch_artist=True, labels=labels)
ax2.set_title('Time Taken Distribution')
ax2.set_xlabel('Filename')
ax2.set_ylabel('Time Taken (s)')
ax2.tick_params(axis='x', rotation=45)

# Adjust layout
plt.tight_layout()

# Show box plots
plt.show()

# Step 4: Plot the bar charts
fig, (ax3, ax4) = plt.subplots(1, 2, figsize=(14, 7))

# Bar chart for GPU usage
ax3.bar(filenames, gpu_usages, color='tab:blue', alpha=0.6)
ax3.set_title('GPU Usage for Different Tasks')
ax3.set_xlabel('Filename')
ax3.set_ylabel('GPU Usage')
ax3.tick_params(axis='x', rotation=45)

# Bar chart for Time Taken
ax4.bar(filenames, time_taken, color='tab:orange', alpha=0.6)
ax4.set_title('Time Taken for Different Tasks')
ax4.set_xlabel('Filename')
ax4.set_ylabel('Time Taken (s)')
ax4.tick_params(axis='x', rotation=45)

# Adjust layout
plt.tight_layout()

# Show bar charts
plt.show()
