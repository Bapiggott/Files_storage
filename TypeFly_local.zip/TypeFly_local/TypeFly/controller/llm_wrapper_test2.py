import os
import requests
import time
import subprocess
import threading

# Define the Ollama API endpoint
OLLAMA_API_URL = "http://localhost:8888"

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(CURRENT_DIR, "outputs_0.30")
os.makedirs(OUTPUT_DIR, exist_ok=True)


class LLMWrapper:
    def __init__(self, temperature=0.3, model_name="llama3.1:70b"):
        self.temperature = temperature
        self.model_name = model_name
        self.gpu_usage = []
        self.stop_monitoring = False  # Initialize the attribute

    def request(self, prompt: str, stream=False) -> str:
        try:
            # Start monitoring GPU usage
            self.gpu_usage = []
            self.stop_monitoring = False  # Ensure monitoring starts
            monitor_thread = threading.Thread(target=self.monitor_gpu_usage)
            monitor_thread.start()

            start_time = time.time()
            response = requests.post(
                f"{OLLAMA_API_URL}/api/generate",
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "temperature": self.temperature,
                    "stream": stream,
                },
                timeout=999
            )
            end_time = time.time()
            elapsed_time = end_time - start_time

            # Stop monitoring GPU usage
            self.stop_monitoring = True
            monitor_thread.join()

            if response.status_code != 200:
                raise Exception("Ollama API request failed")

            text = response.json().get('response', 'No response found')

            # Get final GPU usage after request
            gpu_usage_during = self.gpu_usage

            return text, elapsed_time, gpu_usage_during

        except Exception as e:
            print(f"Request failed: {e}")
            return "Request failed", 0, []

    def monitor_gpu_usage(self):
        while not self.stop_monitoring:
            try:
                result = subprocess.run(
                    ['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory',
                     '--format=csv,noheader,nounits'],
                    stdout=subprocess.PIPE, text=True
                )
                lines = result.stdout.strip().split('\n')
                gpu_usage = ""
                for line in lines:
                    if "ollama_llama_server" in line:
                        gpu_usage = line
                self.gpu_usage.append(gpu_usage)
                time.sleep(1)  # Adjust the sleep time as needed
            except Exception as e:
                print(f"GPU usage monitoring failed: {e}")

# List of models to use
# models = ['deepseek-coder-v2', 'mixtral' , 'mistral']
models = ['llama3.1:8b'] #['deepseek-coder-v2', 'mixtral' , 'mistral', 'llama3.1:8b'] #, 'llama3.1:70b']

# Define your prompts
tasks = [
    "Go to the chair in front of you.",
    "Move towards the table to your right.",
    "Locate the nearest window.",
    "Turn around and face the door.",
    "Approach the painting on the wall.",
    "Find and move to the closest plant.",
    "Go to the couch and stop.",
    "Turn left and go to the TV.",
    "Move to the nearest light source.",
    "Navigate to the bookshelf on the left.",
    "Go towards the water bottle to your left.",
    "Move forward to the desk.",
    "Locate and move to the nearest exit.",
    "Find the carpet on the floor and go to it.",
    "Turn right and go to the fridge.",
    "Approach the whiteboard on the wall.",
    "Go to the nearest chair.",
    "Locate the nearest power outlet.",
    "Move to the window on the right.",
    "Find the bookshelf and approach it.",
    "Go towards the laptop on the desk.",
    "Locate the trash can and move to it.",
    "Approach the nearest lamp.",
    "Turn around and move to the door.",
    "Find the nearest painting and approach it.",
    "Go to the nearest computer monitor.",
    "Move towards the sofa on the right.",
    "Locate the nearest book and approach it.",
    "Go to the coffee table in front of you.",
    "Turn left and go to the door.",
    "Find the nearest window and approach it.",
    "Move towards the clock on the wall.",
    "Go to the nearest painting on the wall.",
    "Approach the chair to your left.",
    "Turn around and go to the table.",
    "Find the nearest fan and approach it.",
    "Move to the nearest mirror.",
    "Locate the nearest kitchen area.",
    "Go to the nearest staircase.",
    "Approach the nearest printer.",
    "Find the nearest cabinet and go to it.",
    "Move towards the nearest fire extinguisher.",
    "Locate the nearest rug and approach it.",
    "Go to the nearest speaker.",
    "Turn right and go to the nearest poster.",
    "Find the nearest door and approach it.",
    "Locate the nearest television.",
    "Move towards the nearest microwave.",
    "Go to the nearest sink.",
    "Approach the nearest clock.",
    "Locate the nearest window and face it."
]

dynamic_tasks = [
    "Go to the tallest object in front of you.",
    "Look around until you see a person holding a water bottle.",
    "Move towards the object that is the farthest away.",
    "Find the largest object in the room and approach it.",
    "Turn around and go to the source of the brightest light.",
    "Scan the room and move to the object with the most vibrant color.",
    "Locate the nearest source of sound and move towards it.",
    "Find an object that is red and approach it.",
    "Look for a person wearing glasses and move towards them.",
    "Identify and approach the object with the most intricate design.",
    "Go towards the source of the air conditioning.",
    "Move to the nearest object that can be opened and close it.",
    "Locate and approach the nearest object that is green.",
    "Find the nearest object with wheels and move towards it.",
    "Look for a door that is slightly ajar and approach it.",
    "Scan the room for any screens and go towards the nearest one.",
    "Locate the nearest object that is making a sound and approach it.",
    "Move towards the nearest object that has a reflective surface.",
    "Find and approach the nearest piece of furniture with cushions.",
    "Look around for any signs and move towards the nearest one.",
    "Identify and move towards the nearest object that is spherical.",
    "Find the nearest corner of the room and go there.",
    "Locate and approach the nearest object that is suspended from the ceiling.",
    "Move towards the nearest source of natural light.",
    "Find the nearest plant and observe its leaves closely.",
    "Locate the nearest person holding a device and approach them.",
    "Scan for the nearest object that appears to be broken and go to it.",
    "Move towards the nearest object that is on the floor.",
    "Look for an object with a unique texture and approach it.",
    "Find the nearest piece of furniture with drawers and go to it.",
    "Locate the nearest object that has text on it and read it.",
    "Identify and move towards the nearest object that is elevated.",
    "Scan the room for any open containers and approach the nearest one.",
    "Find the nearest object that is blue and move towards it.",
    "Locate and approach the nearest object that is being held by a person.",
    "Move towards the nearest object that has lights on it.",
    "Find the nearest object that is covered and uncover it.",
    "Look for an object that is round and approach it.",
    "Locate the nearest object with a digital display and go to it.",
    "Find the nearest source of heat and approach it.",
    "Scan the room for any objects with buttons and approach the nearest one.",
    "Move towards the nearest object that is transparent.",
    "Look for the nearest object that is emitting a smell and go to it.",
    "Find the nearest object with multiple colors and approach it.",
    "Locate and approach the nearest object that is hanging on the wall.",
    "Move towards the nearest object that appears to be heavy.",
    "Look for the nearest object that is soft and approach it.",
    "Find the nearest person with a hat and approach them.",
    "Locate the nearest object that is tall and thin and go to it.",
    "Move towards the nearest object that is shiny."
]

# Process each prompt with each model and save the results in separate files
for model_name in models:
    llm = LLMWrapper(temperature=0.3, model_name=model_name)
    
    for task_type, task_list in [('tasks', tasks), ('dynamic_tasks', dynamic_tasks)]:
        output_file = os.path.join(OUTPUT_DIR, f"{task_type}_{model_name.replace(':', '_')}.txt")
        
        with open(output_file, "w") as f:
            for prompt in task_list:
                prompt = big_prompt = (
                    "You are a robot pilot and you should follow the user's instructions to generate a MiniSpec plan "
                    "to fulfill the task or give advice on user's input if it's not clear or not reasonable.\n\n"
                    "Your response should carefully consider the 'system skills description', the 'scene description', "
                    "the 'task description', and both the 'previous response' and the 'execution status' if they are provided.\n"
                    "The 'system skills description' describes the system's capabilities which include low-level and high-level skills. "
                    "Low-level skills, while fixed, offer direct function calls to control the robot and acquire vision information. "
                    "High-level skills, built with our language 'MiniSpec', are more flexible and can be used to build more complex skills. "
                    "Whenever possible, please prioritize the use of high-level skills, invoke skills using their designated abbreviations, "
                    "and ensure that 'object_name' refers to a specific type of object. If a skill has no argument, you can call it without parentheses.\n\n"
                    "Description of the two skill sets:\n"
                    "- High-level skills:\n"
                    "abbr:s,name:scan,definition:8{?iv($1)==True{->True}tc(45)}->False;,args:[object_name:str],description:Rotate to find object $1 when it's *not* in current scene\n"
                    "abbr:sa,name:scan_abstract,definition:8{_1=p($1);?_1!=False{->_1}tc(45)}->False;,args:[question:str],description:Rotate to find an abstract object by a description $1 when it's *not* in current scene\n"
                    "abbr:o,name:orienting,definition:4{_1=ox($1);?_1>0.6{tc(15)};?_1<0.4{tu(15)};_2=ox($1);?_2<0.6&_2>0.4{->True}}->False;,args:[object_name:str],description:Rotate to align with object $1\n"
                    "abbr:a,name:approach,definition:mf(100);,args:[],description:Approach forward\n"
                    "abbr:g,name:goto,definition:orienting($1);approach();,args:[object_name:str],description:Go to object $1\n\n"
                    "- Low-level skills:\n"
                    "abbr:mf,name:move_forward,args:[distance:int],description:Move forward by a distance\n"
                    "abbr:mb,name:move_backward,args:[distance:int],description:Move backward by a distance\n"
                    "abbr:ml,name:move_left,args:[distance:int],description:Move left by a distance\n"
                    "abbr:mr,name:move_right,args:[distance:int],description:Move right by a distance\n"
                    "abbr:mu,name:move_up,args:[distance:int],description:Move up by a distance\n"
                    "abbr:md,name:move_down,args:[distance:int],description:Move down by a distance\n"
                    "abbr:tc,name:turn_cw,args:[degrees:int],description:Rotate clockwise/right by certain degrees\n"
                    "abbr:tu,name:turn_ccw,args:[degrees:int],description:Rotate counterclockwise/left by certain degrees\n"
                    "abbr:mi,name:move_in_circle,args:[cw:bool],description:Move in circle in cw/ccw\n"
                    "abbr:d,name:delay,args:[milliseconds:int],description:Wait for specified microseconds\n"
                    "abbr:iv,name:is_visible,args:[object_name:str],description:Check the visibility of target object\n"
                    "abbr:ox,name:object_x,args:[object_name:str],description:Get object's X-coordinate in (0,1)\n"
                    "abbr:oy,name:object_y,args:[object_name:str],description:Get object's Y-coordinate in (0,1)\n"
                    "abbr:ow,name:object_width,args:[object_name:str],description:Get object's width in (0,1)\n"
                    "abbr:oh,name:object_height,args:[object_name:str],description:Get object's height in (0,1)\n"
                    "abbr:od,name:object_dis,args:[object_name:str],description:Get object's distance in cm\n"
                    "abbr:p,name:probe,args:[question:str],description:Probe the LLM for reasoning\n"
                    "abbr:l,name:log,args:[text:str],description:Output text to console\n"
                    "abbr:tp,name:take_picture,args:[],description:Take a picture\n"
                    "abbr:rp,name:re_plan,args:[],description:Replanning\n\n"
                    "The 'scene description' is an object list of the current view, containing their names with ID, location, and size (location and size are floats between 0~1). "
                    "This may not be useful if the task is about the environment outside the view.\n"
                    "The 'task description' is a natural language sentence, describing the user's instructions. It may start with '[A]' or '[Q]'. "
                    "'[A]' sentences mean you should generate an execution plan for the robot. '[Q]' sentences mean you should use 'log' to show a literal answer at the end of the plan execution. "
                    "Please carefully reason about the 'task description', you should interpret it and generate a detailed multi-step plan to achieve it as much as you can\n"
                    "The 'execution history' is the actions have been taken from previous response. When they are provided, that means the robot is doing replanning, "
                    "and the user wants to continue the task based on the task and history. You should reason about the 'execution history' and generate a new response accordingly.\n\n"
                    "Here is a list of example 'response' for different 'scene description' and 'task description', and their explanations:\n"
                    "Example 1:\n"
                    "Scene: []\n"
                    "Task: [A] Find a bottle, tell me it's height and take a picture of it.\n"
                    "Reason: no bottle instance in the scene, so we use scan to find bottle, then go and use object_height to get the height and log to output the height, finally use picture to take a picture of the bottle\n"
                    "Response: ?s('bottle')==True{g('bottle');_2=oh('bottle');l(_2);tp};\n\n"
                    "Example 2:\n"
                    "Scene: [apple_5]\n"
                    "Task: [A] Find an apple.\n"
                    "Reason: there is an apple instance in the scene, we just go to the apple_5\n"
                    "Response: g('apple_5');\n\n"
                    "Example 3:\n"
                    "Scene: [apple_3]\n"
                    "Task: [Q] Is there an apple and an orange on your left?\n"
                    "Reason: turn left 90 degrees, then use is_visible to check whether there is an apple on your left\n"
                    "Response: tu(90);?iv('apple')==True&iv('orange'){l('Yes');->True}l('No');->False;\n\n"
                    "Example 4:\n"
                    "Scene: [chair_13,laptop_2]\n"
                    "Task: [A] Go to the chair behind you.\n"
                    "Reason: the chair_13 is not the target because we want the one behind you. So we turn 180 degrees then go to the general object chair, since chair is a large object, we use 80cm as the distance.\n"
                    "Response: tc(180);g('chair');\n\n"
                    "Example 5:\n"
                    "Scene: [chair_3,laptop_1,bottle_5]\n"
                    "Task: [A] Find and go any edible object.\n"
                    "Reason: edible object is abstract and there is no edible object in the scene, so we use scan_abstract to find the edible object\n"
                    "Response: _1=sa('Any edible target here?');?_1!=False{g(_1,10)};\n\n"
                    "Example 6:\n"
                    "Scene: [chair_3,laptop_9]\n"
                    "Task: [A] Turn around with 30 degrees step until you can see some animal.\n"
                    "Reason: we use loop and probe to find animal\n"
                    "Response: 12{_1=p('Any animal target here?');?_1!=False{l(_1);->True}tc(30)}->False;\n\n"
                    "Example 7:\n"
                    "Scene: [chair_3,laptop_9]\n"
                    "Task: [A] If you can see a chair, go find a person, else go find an orange.\n"
                    "Reason: From the scene, we can see a chair, so we use scan to find a person. Since person is a large object, we use 60cm as the distance\n"
                    "Response: _1=s('person');?_1==True{g('person');->True}->False;\n\n"
                    "Example 8:\n"
                    "Scene: [chair_3,laptop_9]\n"
                    "Task: [A] Go to \n"
                    "Reason: The task is too vague, so we use log to output the advice\n"
                    "Response: l('Please give me more information.');\n\n"
                    "Example 9:\n"
                    "Scene: [chair_1 x:0.58 y:0.5 width:0.43 height:0.7, apple_1 x:0.6 y:0.3 width:0.08 height:0.09]\n"
                    "Task: [A] Turn around and go to the apple\n"
                    "Reason: after turning around, we will do replan. We found that the chair is blocking the apple, so we use moving_up to get over the chair and then go to the apple\n"
                    "Response: mu(40);g('apple');\n\n"
                    "Example 10:\n"
                    "Scene: [apple_1 x:0.34 y:0.3 width:0.09 height:0.1, apple_2 x:0.3 y:0.5 width:0.15 height:0.12]\n"
                    "Task: [A] Go to biggest apple\n"
                    "Reason: from the scene, we tell directly that apple_2 is the biggest apple\n"
                    "Response: g('apple_2');\n\n"
                    "Here is the 'scene description':\n"
                    "[bench x:0.44 y:0.42 width:0.15 height:0.18, bench_1 x:0.44 y:0.42 width:0.15 height:0.18]\n\n"
                    "Here is the 'task description':\n"
                    f"[A] {prompt}\n\n"
                    "Here is the 'execution history' (has value if replanning):\n"
                    "None\n\n"
                    "Please generate the response only with a single sentence of MiniSpec program.\n"
                )

                response, time_taken, gpu_usage_during = llm.request(prompt)
                f.write(f"Prompt: {prompt}\n")
                f.write(f"Response: {response}\n")
                f.write(f"Time taken: {time_taken} seconds\n")
                f.write(f"GPU Usage During: {gpu_usage_during}\n")
                f.write("---\n")
                
        print(f"Results for {task_type} with {model_name} saved to {output_file}")

