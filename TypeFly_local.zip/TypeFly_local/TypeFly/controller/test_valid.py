# test_minispec.py

from valid_command_syntax import MiniSpecInterpreter

def run_tests():
    # Define your test vector
    test_vector = [
        "g('apple_5')",
        "tc(180);g('chair')",
        "?s('bottle')==True{g('bottle');_2=oh('bottle');l(_2);tp}"
    ]
    
    # Create an instance of the interpreter
    interpreter = MiniSpecInterpreter()
    
    # Execute the test vector
    try:

        result = interpreter.execute(test_vector)
    
        # Print the result
        print(f"Successful")
    except:
        print("Unsuccessful")
    
    # Print the execution history
    for statement in interpreter.execution_history:
        print(statement)

# Run the tests
if __name__ == "__main__":
    run_tests()

