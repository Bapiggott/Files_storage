import os
import openai
from openai import Stream, ChatCompletion
from transformers import AutoTokenizer, AutoModelForCausalLM, TextGenerationPipeline
import torch

GPT3 = "gpt-3.5-turbo-16k"
GPT4 = "gpt-4"
LLAMA3 = "meta-llama/Meta-Llama-3-8B-Instruct"

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
chat_log_path = os.path.join(CURRENT_DIR, "assets/chat_log.txt")

class LLMWrapper:
    def __init__(self, temperature=0.7, model_name="/media/liu/7b41c748-128b-45b1-abf1-948e6df9fd50/home/px4/bap/TypeFly_local/TypeFly/controller/Meta-Llama-3-8B-Instruct"):
        self.temperature = temperature

        print(f"Loading model: {model_name}")
        if not os.path.exists(model_name):
            print(f"Model directory {model_name} does not exist.")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, local_files_only=True)
        self.model = AutoModelForCausalLM.from_pretrained(model_name, local_files_only=True)
        #self.pipeline = TextGenerationPipeline(model=self.model, tokenizer=self.tokenizer)
        if torch.cuda.is_available():
            self.device = 0
            try:
                self.model.to('cuda')
                print("Model loaded onto GPU.")
            except RuntimeError as e:
                print(f"Failed to load model onto GPU: {e}")
                print("Loading model onto CPU instead.")
                self.device = -1
                self.model.to('cpu')
        else:
            self.device = -1
            self.model.to('cpu')
            print("Model loaded onto CPU.")

        self.pipeline = TextGenerationPipeline(
            model=self.model,
            tokenizer=self.tokenizer,
            device=self.device
        )

    def request(self, prompt: str, model_name="/media/liu/7b41c748-128b-45b1-abf1-948e6df9fd50/home/px4/bap/TypeFly_local/TypeFly/controller/Meta-Llama-3-8B-Instruct", stream=False) -> str:
        # print(stream)
        # max_length: int = 150
        response = self.pipeline(
            prompt,
            # max_length=max_length,
            do_sample=True,
            temperature=self.temperature,
            num_return_sequences=1,
        )[0]["generated_text"]

        # Save the message in a txt
        with open(chat_log_path, "a") as f:
            f.write(f"Prompt: {prompt}\n---\n")
            f.write(f"Response: {response}\n---\n")

        return response


llm = LLMWrapper(temperature=0.7)

# Define your prompt
prompt = "Tell me a joke."

# Get the response
response = llm.request(prompt)
print("Response:", response)
