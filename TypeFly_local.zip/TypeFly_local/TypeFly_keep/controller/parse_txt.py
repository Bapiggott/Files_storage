import os
import json
import re

def calculate_gpu_usage(gpu_usage_list):
    # Extract the last value after the path and convert to integer
    values = [int(re.split(r',\s*', entry)[-1]) for entry in gpu_usage_list if re.split(r',\s*', entry)[-1].isdigit()]
    # Convert from KB to GB and return the maximum value in GB
    return max(values) / 1_000_000 if values else 0


def parse_file(file_path):
    results = []
    with open(file_path, 'r') as file:
        content = file.read()

        # Extract the task description
        task_description_start = content.find("Here is the 'task description':")
        if task_description_start == -1:
            task_description = "Not found"
        else:
            task_description_start += len("Here is the 'task description':")
            task_description_end = content.find('\n', task_description_start)
            task_description = content[task_description_start:task_description_end].strip()

        # Extract the response
        response_start = content.find('Response:')
        response_end = content.find('Time taken:')
        if response_start == -1 or response_end == -1:
            print("hii")
            response = "Not fou99nd"
        else:
            response = content[response_start + len('Response:'):response_end].strip()

        # Extract the time taken
        time_taken_start = content.find('Time taken:')
        time_taken_end = content.find('GPU Usage During:')
        if time_taken_start == -1 or time_taken_end == -1:
            time_taken = "Not found"
        else:
            time_taken = content[time_taken_start:time_taken_end].strip().split('\n', 1)[1].strip()

        # Extract GPU usage information
        gpu_usage_start = content.find('GPU Usage During:')
        gpu_usage_end = content.find('---', gpu_usage_start)
        if gpu_usage_start == -1:
            gpu_usage_gb = 0
        else:
            gpu_usage_raw = content[gpu_usage_start:gpu_usage_end].strip().split('GPU Usage During:')[1].strip()
            gpu_usage_list = re.split(r'\s*,\s*', gpu_usage_raw.strip("[]'"))
            gpu_usage_gb = calculate_gpu_usage(gpu_usage_list)

        results.append({
            "filename": os.path.basename(file_path),
            "task_description": task_description,
            "response": response,
            "gpu_usage_gb": gpu_usage_gb,
            "time_taken": time_taken
        })

    return results


def parse_file1(file_path):
    results = []
    with open(file_path, 'r') as file:
        content = file.read()

        # Extract the task description
        task_description_start = content.find("Here is the 'task description':")
        if task_description_start == -1:
            task_description = "Not found"
        else:
            task_description_start += len("Here is the 'task description':")
            task_description_end = content.find('\n', task_description_start)
            task_description = content[task_description_start:task_description_end].strip()

        # Extract the response
        response_start = content.find('Response:')
        response_end = content.find('Time taken:')
        if response_start == -1 or response_end == -1:
            response = "Not fo9und"
        else:
            response = content[response_start:response_end].strip().split('\n', 1)[1].strip()

        # Extract the time taken
        time_taken_start = content.find('Time taken:')
        time_taken_end = content.find('GPU Usage During:')
        if time_taken_start == -1 or time_taken_end == -1:
            time_taken = "Not found"
        else:
            time_taken = content[time_taken_start:time_taken_end].strip().split('\n', 1)[1].strip()

        # Extract GPU usage information
        gpu_usage_start = content.find('GPU Usage During:')
        gpu_usage_end = content.find('---', gpu_usage_start)
        if gpu_usage_start == -1:
            gpu_usage_gb = 0
        else:
            gpu_usage_raw = content[gpu_usage_start:gpu_usage_end].strip().split('GPU Usage During:')[1].strip()
            gpu_usage_list = re.split(r'\s*,\s*', gpu_usage_raw.strip("[]'"))
            gpu_usage_gb = calculate_gpu_usage(gpu_usage_list)

        results.append({
            "filename": os.path.basename(file_path),
            "task_description": task_description,
            "response": response,
            "gpu_usage_gb": gpu_usage_gb,
            "time_taken": time_taken
        })

    return results

def process_directory(directory_path):
    all_results = []
    for filename in os.listdir(directory_path):
        if filename.endswith('.txt'):
            file_path = os.path.join(directory_path, filename)
            all_results.extend(parse_file(file_path))
    return all_results

def main():
    directory_path = './outputs'
    all_results = process_directory(directory_path)

    with open('result.json', 'w') as outfile:
        json.dump(all_results, outfile, indent=4)

if __name__ == "__main__":
    main()
