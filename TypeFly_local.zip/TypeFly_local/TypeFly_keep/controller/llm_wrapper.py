import os
# import openai
# from openai import Stream, ChatCompletion
# from transformers import AutoTokenizer, AutoModelForCausalLM, TextGenerationPipeline
import requests

GPT3 = "gpt-3.5-turbo-16k"
GPT4 = "gpt-4"
LLAMA3 = "meta-llama/Meta-Llama-3-8B-Instruct"

OLLAMA_API_URL = "http://localhost:8888"
MODEL_NAME = 'llama3.1:8b'

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
chat_log_path = os.path.join(CURRENT_DIR, "assets/chat_log.txt")

class LLMWrapper:
    def __init__(self, temperature=0.7, model_name=MODEL_NAME):
        self.temperature = temperature
        self.model_name = model_name


    def request(self, prompt: str, stream=False) -> str:
        try:
            response = requests.post(
                f"{OLLAMA_API_URL}/api/generate",
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "temperature": self.temperature,
                    "stream": stream,
                },
                timeout=999
            )

            if response.status_code != 200:
                raise Exception("Ollama API request failed")

            text = response.json().get('response', 'No response found')

            with open(chat_log_path, "a") as f:
                f.write(f"Prompt: {prompt}\n---\n")
                f.write(f"Response: {text}\n---\n")

            return text

        except Exception as e:
            print(f"Request failed: {e}")
            return "Request failed"


    def get_embedding(self, text: str) -> list:
        try:
            response = requests.post(
                f"{OLLAMA_API_URL}/api/embeddings",
                json={
                    "model": self.model_name,
                    "prompt": text,
                },
                timeout=999
            )

            if response.status_code != 200:
                raise Exception("Ollama API embedding request failed")

            embedding = response.json().get('embedding', [])
            return embedding

        except Exception as e:
            print(f"Embedding request failed: {e}")
            return []
