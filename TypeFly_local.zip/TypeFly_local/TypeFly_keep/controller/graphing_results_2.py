import json
import matplotlib.pyplot as plt
import numpy as np

# Step 1: Load JSON data from a file
with open('results.json', 'r') as file:
    data = json.load(file)

# Step 2: Extract and group data
dynamic_gpu_usages = []
dynamic_time_taken = []
non_dynamic_gpu_usages = []
non_dynamic_time_taken = []

models = ['llama3.1_70b', 'llama3.1_8b', 'mistral', 'mixtral', 'deepseek-coder-v2']
new_labels = ['Llama 3.1 70B', 'Llama 3.1 8B', 'Mistral 7B', 'Mixtral 8x7B', 'DeepSeek-Coder-V2 16B']

for model in models:
    dynamic_gpu_usages.append([])
    dynamic_time_taken.append([])
    non_dynamic_gpu_usages.append([])
    non_dynamic_time_taken.append([])

for filename, tasks in data.items():
    for task in tasks:
        model = [m for m in models if m in filename][0]
        model_index = models.index(model)
        if filename.startswith('dynamic'):
            dynamic_gpu_usages[model_index].append(task['gpu_usage'])
            dynamic_time_taken[model_index].append(task['time_taken'])
        else:
            non_dynamic_gpu_usages[model_index].append(task['gpu_usage'])
            non_dynamic_time_taken[model_index].append(task['time_taken'])

# Function to remove top 3 values and calculate mean
def remove_top_and_mean(values):
    if len(values) > 3:
        values = sorted(values)[:-3]
    return np.mean(values) if values else 0

# Calculate means for bar heights
dynamic_gpu_means = [remove_top_and_mean(usages) for usages in dynamic_gpu_usages]
dynamic_time_means = [remove_top_and_mean(times) for times in dynamic_time_taken]
non_dynamic_gpu_means = [remove_top_and_mean(usages) for usages in non_dynamic_gpu_usages]
non_dynamic_time_means = [remove_top_and_mean(times) for times in non_dynamic_time_taken]

# Create a new figure for combined plots
fig, axs = plt.subplots(2, 2, figsize=(14, 14))

# Bar chart for GPU usage
x = np.arange(len(models))
width = 0.35

bars1 = axs[0, 0].bar(x - width/2, dynamic_gpu_means, width, label='Dynamic', color='tab:blue')
bars2 = axs[0, 0].bar(x + width/2, non_dynamic_gpu_means, width, label='Non-Dynamic', color='tab:cyan')

axs[0, 0].set_title('Average GPU Usage for Different Models')
axs[0, 0].set_xlabel('Model')
axs[0, 0].set_ylabel('GPU Usage (GB)')
axs[0, 0].set_xticks(x)
axs[0, 0].set_xticklabels(new_labels, rotation=45)
axs[0, 0].legend()

# Bar chart for Time Taken
bars3 = axs[0, 1].bar(x - width/2, dynamic_time_means, width, label='Dynamic', color='tab:orange')
bars4 = axs[0, 1].bar(x + width/2, non_dynamic_time_means, width, label='Non-Dynamic', color='tab:green')

axs[0, 1].set_title('Average Time Taken for Different Models')
axs[0, 1].set_xlabel('Model')
axs[0, 1].set_ylabel('Time Taken (s)')
axs[0, 1].set_xticks(x)
axs[0, 1].set_xticklabels(new_labels, rotation=45)
axs[0, 1].legend()

# Box plot for GPU usage
positions = np.arange(len(models))
width = 0.35

# Dynamic GPU usage box plot
axs[1, 0].boxplot(dynamic_gpu_usages, positions=positions - width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:blue'))
# Non-Dynamic GPU usage box plot
axs[1, 0].boxplot(non_dynamic_gpu_usages, positions=positions + width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:cyan'))

axs[1, 0].set_title('GPU Usage Distribution for Different Models')
axs[1, 0].set_xlabel('Model')
axs[1, 0].set_ylabel('GPU Usage (GB)')
axs[1, 0].set_xticks(positions)
axs[1, 0].set_xticklabels(new_labels, rotation=45)
axs[1, 0].legend(['Dynamic', 'Non-Dynamic'])

# Box plot for Time Taken
# Dynamic Time Taken box plot
axs[1, 1].boxplot(dynamic_time_taken, positions=positions - width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:orange'))
# Non-Dynamic Time Taken box plot
axs[1, 1].boxplot(non_dynamic_time_taken, positions=positions + width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:green'))

axs[1, 1].set_title('Time Taken Distribution for Different Models')
axs[1, 1].set_xlabel('Model')
axs[1, 1].set_ylabel('Time Taken (s)')
axs[1, 1].set_xticks(positions)
axs[1, 1].set_xticklabels(new_labels, rotation=45)
axs[1, 1].legend(['Dynamic', 'Non-Dynamic'])

# Adjust layout for all subplots
plt.tight_layout()

# Show all plots in one figure
plt.show()
