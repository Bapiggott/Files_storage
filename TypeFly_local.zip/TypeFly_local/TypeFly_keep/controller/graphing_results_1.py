import json
import matplotlib.pyplot as plt
import numpy as np

# Step 1: Load JSON data from a file
with open('results.json', 'r') as file:
    data = json.load(file)

# Step 2: Extract and group data
dynamic_gpu_usages = []
dynamic_time_taken = []
non_dynamic_gpu_usages = []
non_dynamic_time_taken = []

models = ['llama3.1_70b', 'llama3.1_8b', 'mistral', 'mixtral', 'deepseek-coder-v2']
new_labels = ['Llama 3.1 70B', 'Llama 3.1 8B', 'Mistral 7B', 'Mixtral 8x7B', 'DeepSeek-Coder-V2 16B']

for model in models:
    dynamic_gpu_usages.append([])
    dynamic_time_taken.append([])
    non_dynamic_gpu_usages.append([])
    non_dynamic_time_taken.append([])

for filename, tasks in data.items():
    for task in tasks:
        model = [m for m in models if m in filename][0]
        model_index = models.index(model)
        if filename.startswith('dynamic'):
            dynamic_gpu_usages[model_index].append(task['gpu_usage'])
            dynamic_time_taken[model_index].append(task['time_taken'])
        else:
            non_dynamic_gpu_usages[model_index].append(task['gpu_usage'])
            non_dynamic_time_taken[model_index].append(task['time_taken'])

# Calculate means for bar heights
dynamic_gpu_means = [np.mean(usages) for usages in dynamic_gpu_usages]
dynamic_time_means = [np.mean(times) for times in dynamic_time_taken]
non_dynamic_gpu_means = [np.mean(usages) for usages in non_dynamic_gpu_usages]
non_dynamic_time_means = [np.mean(times) for times in non_dynamic_time_taken]

# Step 3: Plot the bar charts
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 7))

# Bar chart for GPU usage
x = np.arange(len(models))
width = 0.35

bars1 = ax1.bar(x - width/2, dynamic_gpu_means, width, label='Dynamic', color='tab:blue')
bars2 = ax1.bar(x + width/2, non_dynamic_gpu_means, width, label='Non-Dynamic', color='tab:cyan')

ax1.set_title('Average GPU Usage for Different Models')
ax1.set_xlabel('Model')
ax1.set_ylabel('GPU Usage (GB)')
ax1.set_xticks(x)
ax1.set_xticklabels(new_labels, rotation=45)
ax1.legend()

# Bar chart for Time Taken
bars3 = ax2.bar(x - width/2, dynamic_time_means, width, label='Dynamic', color='tab:orange')
bars4 = ax2.bar(x + width/2, non_dynamic_time_means, width, label='Non-Dynamic', color='tab:green')

ax2.set_title('Average Time Taken for Different Models')
ax2.set_xlabel('Model')
ax2.set_ylabel('Time Taken (s)')
ax2.set_xticks(x)
ax2.set_xticklabels(new_labels, rotation=45)
ax2.legend()

# Adjust layout
plt.tight_layout()

# Show bar charts
plt.show()
