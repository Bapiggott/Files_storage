"""import os
import re

# Define the directory where the output files are stored
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")

def extract_task_description_from_file1(filepath):
    descriptions = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all task descriptions
        task_matches = re.findall(r"GPU Usage During: ([^\n]+)", content)
        descriptions = [match.strip() for match in task_matches]
        print(descriptions)
    return descriptions


def is_divisible_by_three(number):
    return number % 3 == 0

def mb_to_gb(mb):
    return mb / 1024

def extract_task_description_from_file(filepath):
    max_descpript = []
    descriptions = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all task descriptions
        task_matches = re.findall(r"GPU Usage During: \[([^\]]+)\]", content)

        for match in task_matches:
            # Remove unwanted characters and split by commas
            items = re.split(r',\s*', match.strip("[]'"))
            # Convert to a list of items (vector)
            descriptions.append(items)
    #print(descriptions)

    for item in descriptions:
        max_array = []
        index = 0
        index_check = 0
        for item_1 in item:
            #print(item_1)
            item_1 = item_1.replace("'", "").strip()
            if is_divisible_by_three(index+1):
                try:
                    max_array.append(int(item_1))

                except Exception as e:
                    print("*****")
                    print(item_1)
                    print(item)
                    print(e)

            if index == 0 and item_1 == "":
                index -= 1
            index += 1
            index_check += 1
        max_descpript.append(mb_to_gb(max(max_array)))
    #print('---')
    #print(max_descpript)
    return max_descpript

def extract_descriptions_for_each_file(output_dir):
    file_descriptions = {}
    for filename in os.listdir(output_dir):
        if filename.endswith(".txt"):
            filepath = os.path.join(output_dir, filename)
            file_descriptions[filename] = extract_task_description_from_file(filepath)
    return file_descriptions

# Extract task descriptions from all output files
descriptions_per_file = extract_descriptions_for_each_file(OUTPUT_DIR)

# Print the task descriptions for each file
for filename, descriptions in descriptions_per_file.items():
    print(f"File: {filename}")
    print(f"Extracted task descriptions: {descriptions}")
    print()

"""
"""import os
import json
import re

# Define the directory where the output files are stored
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")


def extract_task_description_from_file(filepath):
    descriptions = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all task descriptions
        task_matches = re.findall(r"Here is the 'task description':\n([^\n]+)", content)
        descriptions = [match.strip() for match in task_matches]
    return descriptions


def extract_time_from_file(filepath):
    times = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all time values
        time_matches = re.findall(r"Time taken: (\d+(\.\d+)?) seconds", content)
        times = [float(match[0]) for match in time_matches]
    return times


def extract_response_from_file(filepath):
    responses = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all responses
        response_matches = re.findall(
            r"Please generate the response only with a single sentence of MiniSpec program.\n\nResponse:  ([^\n]+)",
            content)
        responses = [match.strip() for match in response_matches]
    return responses


def extract_data_for_each_file(output_dir):
    file_data = {}
    for filename in os.listdir(output_dir):
        if filename.endswith(".txt"):
            filepath = os.path.join(output_dir, filename)
            tasks = extract_task_description_from_file(filepath)
            times = extract_time_from_file(filepath)
            responses = extract_response_from_file(filepath)

            # Combine task, time, and response for each file
            paired_data = []
            for i in range(max(len(tasks), len(times), len(responses))):
                item = {
                    "filename": filename,
                    "task_description": tasks[i] if i < len(tasks) else "Not found",
                    "response": responses[i] if i < len(responses) else "Not found",
                    "time_taken": times[i] if i < len(times) else "Not found"
                }
                paired_data.append(item)

            file_data[filename] = paired_data
    return file_data


def main():
    all_results = extract_data_for_each_file(OUTPUT_DIR)

    with open('results.json', 'w') as outfile:
        json.dump(all_results, outfile, indent=4)


if __name__ == "__main__":
    main()
"""
import os
import json
import re

# Define the directory where the output files are stored
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs_1")


def extract_task_description_from_file(filepath):
    descriptions = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all task descriptions
        task_matches = re.findall(r"Here is the 'task description':\n([^\n]+)", content)
        descriptions = [match.strip() for match in task_matches]
    return descriptions


def extract_gpu_usage_from_file(filepath):
        max_descpript = []
        descriptions = []
        with open(filepath, "r") as file:
            content = file.read()
            # Use regular expression to find all task descriptions
            task_matches = re.findall(r"GPU Usage During: \[([^\]]+)\]", content)

            for match in task_matches:
                # Remove unwanted characters and split by commas
                items = re.split(r',\s*', match.strip("[]'"))
                # Convert to a list of items (vector)
                descriptions.append(items)
        # print(descriptions)

        for item in descriptions:
            max_array = []
            index = 0
            index_check = 0
            for item_1 in item:
                # print(item_1)
                item_1 = item_1.replace("'", "").strip()
                if is_divisible_by_three(index + 1):
                    try:
                        max_array.append(int(item_1))

                    except Exception as e:
                        print("*****")
                        print(index)
                        print(index_check)
                        print(item_1)
                        print(item)
                        print(e)

                if item_1 == "":#index == 0 and item_1 == "":
                    index -= 1
                index += 1
                index_check += 1
            max_descpript.append(mib_to_gb(max(max_array)))
        # print('---')
        # print(max_descpript)
        return max_descpript


def extract_time_from_file(filepath):
    times = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all time values
        time_matches = re.findall(r"Time taken: (\d+(\.\d+)?) seconds", content)
        times = [float(match[0]) for match in time_matches]
    return times


def extract_response_from_file1(filepath):
    responses = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all responses
        response_matches = re.findall(
            r"Please generate the response only with a single sentence of MiniSpec program.\n\nResponse:  ([^\n]+)",
            content)
        responses = [match.strip() for match in response_matches]
    print(len(responses))
    return responses


def extract_response_from_file(filepath):
    responses = []
    with open(filepath, "r") as file:
        content = file.read()
        # Use regular expression to find all responses, making the newlines optional
        response_matches = re.findall(
            r"Please generate the response only with a single sentence of MiniSpec program.\s*Response:\s*([^\n]+)",
            content)
        responses = [match.strip() for match in response_matches]
    print(len(responses))
    return responses


def extract_data_for_each_file(output_dir):
    file_data = {}
    for filename in os.listdir(output_dir):
        if filename.endswith(".txt"):
            filepath = os.path.join(output_dir, filename)
            tasks = extract_task_description_from_file(filepath)
            gpu_usages = extract_gpu_usage_from_file(filepath)
            times = extract_time_from_file(filepath)
            responses = extract_response_from_file(filepath)

            # Combine task, GPU usage, time, and response for each file
            paired_data = []
            for i in range(max(len(tasks), len(gpu_usages), len(times), len(responses))):
                item = {
                    "filename": filename,
                    "task_description": tasks[i] if i < len(tasks) else "Not found",
                    "gpu_usage": gpu_usages[i] if i < len(gpu_usages) else "Not found",
                    "response": responses[i] if i < len(responses) else "Not found",
                    "time_taken": times[i] if i < len(times) else "Not found"
                }
                paired_data.append(item)

            file_data[filename] = paired_data
    return file_data


def is_divisible_by_three(number):
    return number % 3 == 0


def mib_to_gb(mib):
    gb = mib * 0.00107374182
    return gb


def main():
    all_results = extract_data_for_each_file(OUTPUT_DIR)

    with open('results1.json', 'w') as outfile:
        json.dump(all_results, outfile, indent=4)


if __name__ == "__main__":
    main()
