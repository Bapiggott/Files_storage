import os
import requests
import time
import subprocess
import threading

# Define the Ollama API endpoint
OLLAMA_API_URL = "http://localhost:8888"

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(CURRENT_DIR, "outputs_2")
os.makedirs(OUTPUT_DIR, exist_ok=True)


class LLMWrapper:
    def __init__(self, temperature=0.7, model_name="llama3.1:70b"):
        self.temperature = temperature
        self.model_name = model_name
        self.gpu_usage = []
        self.stop_monitoring = False  # Initialize the attribute

    def request(self, prompt: str, stream=False) -> str:
        try:
            # Start monitoring GPU usage
            self.gpu_usage = []
            self.stop_monitoring = False  # Ensure monitoring starts
            monitor_thread = threading.Thread(target=self.monitor_gpu_usage)
            monitor_thread.start()

            start_time = time.time()
            response = requests.post(
                f"{OLLAMA_API_URL}/api/generate",
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "temperature": self.temperature,
                    "stream": stream,
                },
                timeout=999
            )
            end_time = time.time()
            elapsed_time = end_time - start_time

            # Stop monitoring GPU usage
            self.stop_monitoring = True
            monitor_thread.join()

            if response.status_code != 200:
                raise Exception("Ollama API request failed")

            text = response.json().get('response', 'No response found')

            # Get final GPU usage after request
            gpu_usage_during = self.gpu_usage

            return text, elapsed_time, gpu_usage_during

        except Exception as e:
            print(f"Request failed: {e}")
            return "Request failed", 0, []

    def monitor_gpu_usage(self):
        while not self.stop_monitoring:
            try:
                result = subprocess.run(
                    ['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory',
                     '--format=csv,noheader,nounits'],
                    stdout=subprocess.PIPE, text=True
                )
                lines = result.stdout.strip().split('\n')
                gpu_usage = ""
                for line in lines:
                    if "ollama_llama_server" in line:
                        gpu_usage = line
                self.gpu_usage.append(gpu_usage)
                time.sleep(1)  # Adjust the sleep time as needed
            except Exception as e:
                print(f"GPU usage monitoring failed: {e}")

# List of models to use
# models = ['deepseek-coder-v2', 'mixtral' , 'mistral']
models = ['deepseek-coder-v2', 'mixtral' , 'mistral', 'llama3.1:8b', 'llama3.1:70b']

# Define your prompts
tasks = [
    "Go to the chair in front of you.",
    "Move towards the table to your right.",
    "Locate the nearest window.",
    "Turn around and face the door.",
    "Approach the painting on the wall.",
    "Find and move to the closest plant.",
    "Go to the couch and stop.",
    "Turn left and go to the TV.",
    "Move to the nearest light source.",
    "Navigate to the bookshelf on the left.",
    "Go towards the water bottle to your left.",
    "Move forward to the desk.",
    "Locate and move to the nearest exit.",
    "Find the carpet on the floor and go to it.",
    "Turn right and go to the fridge.",
    "Approach the whiteboard on the wall.",
    "Go to the nearest chair.",
    "Locate the nearest power outlet.",
    "Move to the window on the right.",
    "Find the bookshelf and approach it.",
    "Go towards the laptop on the desk.",
    "Locate the trash can and move to it.",
    "Approach the nearest lamp.",
    "Turn around and move to the door.",
    "Find the nearest painting and approach it.",
    "Go to the nearest computer monitor.",
    "Move towards the sofa on the right.",
    "Locate the nearest book and approach it.",
    "Go to the coffee table in front of you.",
    "Turn left and go to the door.",
    "Find the nearest window and approach it.",
    "Move towards the clock on the wall.",
    "Go to the nearest painting on the wall.",
    "Approach the chair to your left.",
    "Turn around and go to the table.",
    "Find the nearest fan and approach it.",
    "Move to the nearest mirror.",
    "Locate the nearest kitchen area.",
    "Go to the nearest staircase.",
    "Approach the nearest printer.",
    "Find the nearest cabinet and go to it.",
    "Move towards the nearest fire extinguisher.",
    "Locate the nearest rug and approach it.",
    "Go to the nearest speaker.",
    "Turn right and go to the nearest poster.",
    "Find the nearest door and approach it.",
    "Locate the nearest television.",
    "Move towards the nearest microwave.",
    "Go to the nearest sink.",
    "Approach the nearest clock.",
    "Locate the nearest window and face it."
]

dynamic_tasks = [
    "Go to the tallest object in front of you.",
    "Look around until you see a person holding a water bottle.",
    "Move towards the object that is the farthest away.",
    "Find the largest object in the room and approach it.",
    "Turn around and go to the source of the brightest light.",
    "Scan the room and move to the object with the most vibrant color.",
    "Locate the nearest source of sound and move towards it.",
    "Find an object that is red and approach it.",
    "Look for a person wearing glasses and move towards them.",
    "Identify and approach the object with the most intricate design.",
    "Go towards the source of the air conditioning.",
    "Move to the nearest object that can be opened and close it.",
    "Locate and approach the nearest object that is green.",
    "Find the nearest object with wheels and move towards it.",
    "Look for a door that is slightly ajar and approach it.",
    "Scan the room for any screens and go towards the nearest one.",
    "Locate the nearest object that is making a sound and approach it.",
    "Move towards the nearest object that has a reflective surface.",
    "Find and approach the nearest piece of furniture with cushions.",
    "Look around for any signs and move towards the nearest one.",
    "Identify and move towards the nearest object that is spherical.",
    "Find the nearest corner of the room and go there.",
    "Locate and approach the nearest object that is suspended from the ceiling.",
    "Move towards the nearest source of natural light.",
    "Find the nearest plant and observe its leaves closely.",
    "Locate the nearest person holding a device and approach them.",
    "Scan for the nearest object that appears to be broken and go to it.",
    "Move towards the nearest object that is on the floor.",
    "Look for an object with a unique texture and approach it.",
    "Find the nearest piece of furniture with drawers and go to it.",
    "Locate the nearest object that has text on it and read it.",
    "Identify and move towards the nearest object that is elevated.",
    "Scan the room for any open containers and approach the nearest one.",
    "Find the nearest object that is blue and move towards it.",
    "Locate and approach the nearest object that is being held by a person.",
    "Move towards the nearest object that has lights on it.",
    "Find the nearest object that is covered and uncover it.",
    "Look for an object that is round and approach it.",
    "Locate the nearest object with a digital display and go to it.",
    "Find the nearest source of heat and approach it.",
    "Scan the room for any objects with buttons and approach the nearest one.",
    "Move towards the nearest object that is transparent.",
    "Look for the nearest object that is emitting a smell and go to it.",
    "Find the nearest object with multiple colors and approach it.",
    "Locate and approach the nearest object that is hanging on the wall.",
    "Move towards the nearest object that appears to be heavy.",
    "Look for the nearest object that is soft and approach it.",
    "Find the nearest person with a hat and approach them.",
    "Locate the nearest object that is tall and thin and go to it.",
    "Move towards the nearest object that is shiny."
]

# Process each prompt with each model and save the results in separate files
for model_name in models:
    llm = LLMWrapper(temperature=0.7, model_name=model_name)
    
    for task_type, task_list in [('tasks', tasks), ('dynamic_tasks', dynamic_tasks)]:
        output_file = os.path.join(OUTPUT_DIR, f"{task_type}_{model_name.replace(':', '_')}.txt")
        
        with open(output_file, "w") as f:
            for prompt in task_list:
                big_prompt = f"""You are writing a script for a drone using python. Below are some commands to control a Tello drone. Below are the detailed descriptions and examples of each command.

Commands:

1. move(direction, x)
   - Description: Move the Tello drone in a specified direction with a distance of x centimeters.
   - Parameters:
     - direction (str): Direction of movement ('up', 'down', 'left', 'right', 'forward', 'back').
     - x (int): Distance in centimeters (20-500).

2. rotate_clockwise(x)
   - Description: Rotate the drone x degrees clockwise.
   - Parameters:
     - x (int): Degrees of rotation (1-360).

3. rotate_counter_clockwise(x)
   - Description: Rotate the drone x degrees counter-clockwise.
   - Parameters:
     - x (int): Degrees of rotation (1-3600).

4. streamoff()
   - Description: Turn off video streaming.

5. streamon()
   - Description: Turn on video streaming. Use tello.get_frame_read afterwards. Video streaming is supported on all Tello models when in AP mode. Note: If the response is 'Unknown command', update the Tello firmware using the official Tello app.

6. takeoff()
   - Description: Automatic takeoff.

7. land()
   - Description: Automatic landing.

8. get_battery()
   - Description: Get the current battery percentage.
   - Returns: Battery percentage (int, 0-100).

Other Non-TypeFly Commands:

import yolo_commands

1. get_scene_description()
   - Description: Get the current view of objects in the scene.
   - Returns:
       - scene_description (List[str]): A list of formatted strings, each describing a detected object and its bounding box coordinates.
   - Example Output: - ["handbag x:0.61 y:0.36 width:0.07 height:0.12", "suitcase x:0.61 y:0.40 width:0.07 height:0.12", "handbag_1 x:0.60 y:0.36 width:0.07 height:0.12", "suitcase_2 x:0.61 y:0.49 width:0.14 height:0.21"]

2. go_to(x)
    - Description: Move towards a specified object.
    - Parameters:
        - x (str): The target object to move towards.
    - Returns:
        - bool: True if the object is found and reached, False otherwise.

import vision_skill_wrapper

1. is_visible(object_name)
   - Description: Check if a specific object is visible.
   - Parameters:
     - object_name (str): Name of the object to check visibility for.
   - Returns: Tuple[bool, bool]: True if object is visible, False otherwise.

2. object_x(object_name)
   - Description: Get the x-coordinate of a specified object.
   - Parameters:
     - object_name (str): Name of the object to get the x-coordinate for.
   - Returns: Tuple[Union[float, str], bool]: x-coordinate if object is visible, error message otherwise.

3. object_y(object_name)
   - Description: Get the y-coordinate of a specified object.
   - Parameters:
     - object_name (str): Name of the object to get the y-coordinate for.
   - Returns: Tuple[Union[float, str], bool]: y-coordinate if object is visible, error message otherwise.

4. object_width(object_name)
   - Description: Get the width of a specified object.
   - Parameters:
     - object_name (str): Name of the object to get the width for.
   - Returns: Tuple[Union[float, str], bool]: Width if object is visible, error message otherwise.

5. object_height(object_name)
   - Description: Get the height of a specified object.
   - Parameters:
     - object_name (str): Name of the object to get the height for.
   - Returns: Tuple[Union[float, str], bool]: Height if object is visible, error message otherwise.

6. object_distance(object_name)
   - Description: Get the distance to a specified object.
   - Parameters:
     - object_name (str): Name of the object to get the distance for.
   - Returns: Tuple[Union[int, str], bool]: Distance if object is visible, error message otherwise.

Example Basic Code:

    Task: Rotate until you find a person.  If you do not find someone after completing a full circle, land.

    Code:
        def find_person_and_land():
            tello = Tello()
            tello.connect()

            found_person = False
            rotation_angle = 0

            while rotation_angle < 360:
                tello.rotate_clockwise(30)
                rotation_angle += 30

                scene_description = yolo_commands.get_scene_description()
                if yolo_commands.is_visible("person", scene_description):
                    found_person = True
                    break

        find_person_and_land()

Task: {prompt}

Important: Note that the drone is already taken off. You do not need to take it off nor land it nor need to add any import statements.

Format: Your response should only give me python code, no reasoning or other not needed information. Do not include comments within your code.
"""

                response, time_taken, gpu_usage_during = llm.request(big_prompt)
                f.write(f"Prompt: {prompt}\n")
                f.write(f"Response: {response}\n")
                f.write(f"Time taken: {time_taken} seconds\n")
                f.write(f"GPU Usage During: {gpu_usage_during}\n")
                f.write("---\n")
                
        print(f"Results for {task_type} with {model_name} saved to {output_file}")

