from djitellopy import Tello

tello = Tello()

tello.connect()
tello.takeoff()

tello.move('forward', 100)
tello.move('back', 100)

tello.rotate_clockwise(360)

tello.land()
