import os
import requests
import json
import torch

# Define the Ollama API endpoint and your model name
OLLAMA_API_URL = "http://localhost:8888"
MODEL_NAME = 'deepseek-coder-v2' #llama3.1:70b'#"meta-llama/Meta-Llama-3-8B-Instruct"  # Adjust as needed

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
chat_log_path = os.path.join(CURRENT_DIR, "assets/chat_log.txt")

class LLMWrapper:
    def __init__(self, temperature=0.7, model_name=MODEL_NAME):
        self.temperature = temperature
        self.model_name = model_name

    def request(self, prompt: str, stream=False) -> str:
        try:
            response = requests.post(
                f"{OLLAMA_API_URL}/api/generate",
                json={
                    "model": self.model_name,
                    "prompt": prompt,
                    "temperature": self.temperature,
                    "stream": stream,
                },
                timeout=999
            )
            
            if response.status_code != 200:
                raise Exception("Ollama API request failed")

            text = response.json().get('response', 'No response found')
            
            # Save the message in a txt
            with open(chat_log_path, "a") as f:
                f.write(f"Prompt: {prompt}\n---\n")
                f.write(f"Response: {text}\n---\n")

            return text
        
        except Exception as e:
            print(f"Request failed: {e}")
            return "Request failed"

    def get_embedding(self, text: str) -> list:
        try:
            response = requests.post(
                f"{OLLAMA_API_URL}/api/embeddings",
                json={
                    "model": self.model_name,
                    "prompt": text,
                },
                timeout=999
            )
            
            if response.status_code != 200:
                raise Exception("Ollama API embedding request failed")

            embedding = response.json().get('embedding', [])
            return embedding
        
        except Exception as e:
            print(f"Embedding request failed: {e}")
            return []

# Usage example
llm = LLMWrapper(temperature=0.7)

# Define your prompt
prompt = """
You are writing a script for a drone using python. Below are some  commands to control a Tello drone. Below are the detailed descriptions and examples of each command.

Commands:

1. move(direction, x)
   - Description: Move the Tello drone in a specified direction with a distance of x centimeters.
   - Parameters:
     - direction (str): Direction of movement ('up', 'down', 'left', 'right', 'forward', 'back').
     - x (int): Distance in centimeters (20-500).

2. rotate_clockwise(x)
   - Description: Rotate the drone x degrees clockwise.
   - Parameters:
     - x (int): Degrees of rotation (1-360).

3. rotate_counter_clockwise(x)
   - Description: Rotate the drone x degrees counter-clockwise.
   - Parameters:
     - x (int): Degrees of rotation (1-3600).

4. streamoff()
   - Description: Turn off video streaming.

5. streamon()
   - Description: Turn on video streaming. Use tello.get_frame_read afterwards. Video streaming is supported on all Tello models when in AP mode. Note: If the response is 'Unknown command', update the Tello firmware using the official Tello app.

6. takeoff()
   - Description: Automatic takeoff.

7. land()
   - Description: Automatic landing.

8. get_battery()
   - Description: Get the current battery percentage.
   - Returns: Battery percentage (int, 0-100).

Other Non-TypeFly Commands:

import yolo_commands

1. get_scene_description()
   - Description: Get the current view of objects in the scene.
   - Returns: 
       - scene_description (List[str]): A list of formatted strings, each describing a detected object and its bounding box coordinates. 
   - Example Output: - ["handbag x:0.61 y:0.36 width:0.07 height:0.12", "suitcase x:0.61 y:0.40 width:0.07 height:0.12", "handbag_1 x:0.60 y:0.36 width:0.07 height:0.12", "suitcase_2 x:0.61 y:0.49 width:0.14 height:0.21"]
2. is_visible(x, scene_description)
    - Description: Check the visibility of a target object, which can be a type of object or concept (e.g., "TV", "something edible", "person", "drinkable").
                For instance, if you are looking for something drinkable you would only do is_visible("Something for me to read", scene_description) and nothing else. This is going to be ran through a large language model, so the description can be quite broad.
    - Parameters:
        - x (str): Phrase to be checked.
        - scene_description (List[str]): Output from get_scene_description().
        
3. go_to(x)
    - Description: Move towards a specified object.
    - Parameters:
        - x (str): The target object to move towards.
    - Returns:
        - bool: True if the object is found and reached, False otherwise.
Example Basic Code:

    Task: Rotate until you find a person.  If you do not find someone after completing a full circle, land.
    
    Code:
        from djitellopy import Tello
        import yolo_commands
        
        def find_person_and_land():
            tello = Tello()
            tello.connect()
            tello.takeoff()
        
            found_person = False
            rotation_angle = 0
        
            while rotation_angle < 360:
                tello.rotate_clockwise(30)
                rotation_angle += 30
        
                scene_description = yolo_commands.get_scene_description()
                if yolo_commands.is_visible("person", scene_description):
                    found_person = True
                    break
        
            tello.land()
        
        find_person_and_land()


Task: I want you to look around (full circle) and try to find something edible for me to eat. If you cannot find anything to eat, find me something drinkable.  If you find me anything drinkable or ediable, go towards it.

Format: Your response should only give me python code, no reasoning or other not needed information
"""


# Get the response
response = llm.request(prompt)
print("prompt:", prompt)
print("Response:", response)

# Get the embedding
embedding = llm.get_embedding("example text")
# print("Embedding:", embedding)

