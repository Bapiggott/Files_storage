import json
import matplotlib.pyplot as plt
import numpy as np

# Function to load data from a file and extract time taken
def load_time_data(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    dynamic_time_taken = [[] for _ in models]
    non_dynamic_time_taken = [[] for _ in models]
    
    for filename, tasks in data.items():
        for task in tasks:
            model = [m for m in all_models if m in filename][0]
            if model in models:
                model_index = models.index(model)
                if filename.startswith('dynamic'):
                    dynamic_time_taken[model_index].append(task['time_taken'])
                else:
                    non_dynamic_time_taken[model_index].append(task['time_taken'])
                
    return dynamic_time_taken, non_dynamic_time_taken

# Function to remove top 3 values and calculate mean
def remove_top_and_mean(values):
    if len(values) > 3:
        values = sorted(values)[:-3]
    return np.mean(values) if values else 0

# Models and labels
all_models = ['llama3.1_70b', 'llama3.1_8b', 'mistral', 'mixtral', 'deepseek-coder-v2']
models = ['llama3.1_8b', 'mistral', 'deepseek-coder-v2']
new_labels = ['Llama 3.1 8B', 'Mistral 7B', 'DeepSeek-Coder-V2 16B']

# Load data from both JSON files
dynamic_time_taken_1, non_dynamic_time_taken_1 = load_time_data('results2.json')
dynamic_time_taken_2, non_dynamic_time_taken_2 = load_time_data('results.json')

# Calculate means for bar heights
dynamic_time_means_1 = [remove_top_and_mean(times) for times in dynamic_time_taken_1]
non_dynamic_time_means_1 = [remove_top_and_mean(times) for times in non_dynamic_time_taken_1]
dynamic_time_means_2 = [remove_top_and_mean(times) for times in dynamic_time_taken_2]
non_dynamic_time_means_2 = [remove_top_and_mean(times) for times in non_dynamic_time_taken_2]

# Create a new figure for combined plots
fig, axs = plt.subplots(2, 2, figsize=(14, 14))

# Bar chart for Time Taken from results1.json
x = np.arange(len(models))
width = 0.35

bars1 = axs[0, 0].bar(x - width/2, dynamic_time_means_1, width, label='Dynamic', color='tab:orange')
bars2 = axs[0, 0].bar(x + width/2, non_dynamic_time_means_1, width, label='Non-Dynamic', color='tab:green')

axs[0, 0].set_title('Average Time Taken for Different Models (Python)')
axs[0, 0].set_xlabel('Model')
axs[0, 0].set_ylabel('Time Taken (s)')
axs[0, 0].set_xticks(x)
axs[0, 0].set_xticklabels(new_labels, rotation=45)
axs[0, 0].legend()

# Box plot for Time Taken from results1.json
positions = np.arange(len(models))

# Dynamic Time Taken box plot
axs[1, 0].boxplot(dynamic_time_taken_1, positions=positions - width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:orange'))
# Non-Dynamic Time Taken box plot
axs[1, 0].boxplot(non_dynamic_time_taken_1, positions=positions + width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:green'))

axs[1, 0].set_title('Time Taken Distribution for Different Models (Python)')
axs[1, 0].set_xlabel('Model')
axs[1, 0].set_ylabel('Time Taken (s)')
axs[1, 0].set_xticks(positions)
axs[1, 0].set_xticklabels(new_labels, rotation=45)
axs[1, 0].legend(['Dynamic', 'Non-Dynamic'])

# Bar chart for Time Taken from results.json
bars3 = axs[0, 1].bar(x - width/2, dynamic_time_means_2, width, label='Dynamic', color='tab:blue')
bars4 = axs[0, 1].bar(x + width/2, non_dynamic_time_means_2, width, label='Non-Dynamic', color='tab:cyan')

axs[0, 1].set_title('Average Time Taken for Different Models (MiniSpec)')
axs[0, 1].set_xlabel('Model')
axs[0, 1].set_ylabel('Time Taken (s)')
axs[0, 1].set_xticks(x)
axs[0, 1].set_xticklabels(new_labels, rotation=45)
axs[0, 1].legend()

# Box plot for Time Taken from results.json
# Dynamic Time Taken box plot
axs[1, 1].boxplot(dynamic_time_taken_2, positions=positions - width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:blue'))
# Non-Dynamic Time Taken box plot
axs[1, 1].boxplot(non_dynamic_time_taken_2, positions=positions + width/2, widths=0.3, patch_artist=True, boxprops=dict(facecolor='tab:cyan'))

axs[1, 1].set_title('Time Taken Distribution for Different Models (MiniSpec)')
axs[1, 1].set_xlabel('Model')
axs[1, 1].set_ylabel('Time Taken (s)')
axs[1, 1].set_xticks(positions)
axs[1, 1].set_xticklabels(new_labels, rotation=45)
axs[1, 1].legend(['Dynamic', 'Non-Dynamic'])

# Adjust layout for all subplots
plt.tight_layout()

# Show all plots in one figure
plt.show()

