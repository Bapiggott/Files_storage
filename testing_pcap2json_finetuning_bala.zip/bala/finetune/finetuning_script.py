from huggingface_hub import notebook_login
from datasets import Dataset
# notebook_login()

from datasets import load_dataset

import pandas as pd

run_name = "udp_small_llama2_7b"

model_name = "meta-llama/Llama-2-7b-hf"
dataset_name = '../code/csvs/sub_dataset_0.json.csv'# '/home/px4/bala/finetune/data_udp.csv'
final_model_name = run_name

output_dir = "./results_" + run_name
per_device_train_batch_size = 1
gradient_accumulation_steps = 12
optim = "paged_adamw_32bit"
save_steps = 1000
logging_steps = 10
learning_rate = 2e-4
max_grad_norm = 0.3
max_steps = None
warmup_ratio = 0.03
lr_scheduler_type = "constant"
epoch = 1

max_seq_length = 1024

print(f'reading csv: {dataset_name}')
df = pd.read_csv(dataset_name)
print(f'csv read completed...')
dataset = Dataset.from_pandas(df)
print(f'csv converted to dataframe...')

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, AutoTokenizer, AutoModelForSeq2SeqLM

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16,
)

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    quantization_config=bnb_config,
    trust_remote_code=True,
    device_map={"": 0}
)
model.config.use_cache = False
print(f'pretrained model downloaded...')

tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

from peft import LoraConfig, get_peft_model

lora_alpha = 16
lora_dropout = 0.1
lora_r = 64

peft_config = LoraConfig(
    lora_alpha=lora_alpha,
    lora_dropout=lora_dropout,
    r=lora_r,
    bias="none",
    task_type="CAUSAL_LM"
)

from transformers import TrainingArguments

training_arguments = TrainingArguments(
    output_dir=output_dir,
    per_device_train_batch_size=per_device_train_batch_size,
    gradient_accumulation_steps=gradient_accumulation_steps,
    optim=optim,
    report_to="wandb",
    run_name=run_name,
    save_steps=save_steps,
    logging_steps=logging_steps,
    learning_rate=learning_rate,
    fp16=True,
    max_grad_norm=max_grad_norm,
    warmup_ratio=warmup_ratio,
    group_by_length=True,
    num_train_epochs=epoch,
    lr_scheduler_type=lr_scheduler_type,
)

from trl import SFTTrainer



trainer = SFTTrainer(
    model=model,
    train_dataset=dataset,
    peft_config=peft_config,
    dataset_text_field="text",
    max_seq_length=max_seq_length,
    tokenizer=tokenizer,
    args=training_arguments,
)

for name, module in trainer.model.named_modules():
    if "norm" in name:
        module = module.to(torch.float32)

print(f'training starting... ')
trainer.train()
print(f'training ended... ')

model_to_save = trainer.model.module if hasattr(trainer.model, 'module') else trainer.model  # Take care of distributed/parallel training
model_to_save.save_pretrained("adapters_" + run_name)
print(f'finetuned model saved... ')

from transformers import AutoModelForCausalLM, PretrainedConfig
import torch

model = AutoModelForCausalLM.from_pretrained(model_name, device_map={"":0}, trust_remote_code=True, torch_dtype=torch.float16)

from peft import PeftModel

# load perf model with new adapters
model = PeftModel.from_pretrained(
    model,
    "adapters_" + run_name,
)

print("Merging...")

model = model.merge_and_unload() # merge adapters with

print("Saving Final Merged Model")

model.save_pretrained(final_model_name)

from transformers import AutoTokenizer

print("Saving Tokenizer")

tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
tokenizer.save_pretrained(final_model_name)
