import os
import ijson


def count(filename):
    with open(filename, 'rb') as file:
        jsonobj = ijson.items(file, 'item', use_float=True)
        total_datasets = sum(1 for _ in jsonobj)
        print(f'File: {filename}\nTotal number of entries: {total_datasets}')


if __name__ == "__main__":
    input_file = 'output_predictions_test_udp_small_distilgpt2.json'
    count(input_file)

    # File: output_predictions_test_udp_small_distilgpt2.json
    # Total number of entries: 3274
    # input_file = 'datasets/sub_dataset_59.json
