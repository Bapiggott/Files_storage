import pyshark
import json
import os
from datasketch import MinHash

def unique_alphabet(flags):
    return sorted(set(flags))

def flags_to_string(flags, alphabet):
    return ''.join([str(alphabet.index(flag)) if flag in alphabet else '' for flag in flags])

def shorten_flags_string(flags_string):
    shortened = ''
    prev_char = ''
    for char in flags_string:
        if char == prev_char:
            if shortened[-1] != '*':  # Avoid adding multiple '*' for long sequences
                shortened += '*'
        else:
            shortened += char
        prev_char = char
    return shortened

def create_minhash(signature):
    m = MinHash()
    for d in signature:
        m.update(d.encode('utf8'))
    return m

# Example pcap file paths - replace with actual paths
pcap_directory = '~/PX4-Autopilot/code_test/missions'   #'/home/px4/bala/code/tcp/test/pcaps'
pcap_paths = [os.path.join(pcap_directory, f) for f in os.listdir(pcap_directory) if f.endswith('.pcap')]

all_flags = []
output = []

# Read each pcap file and extract TCP flags
for path in pcap_paths:
    file_flags = []
    capture = pyshark.FileCapture(path, only_summaries=False, use_json=True)
    for packet in capture:
        try:
            if 'TCP' in packet:
                flags = packet.tcp.flags
                if flags:
                    file_flags.append(flags)
        except AttributeError:
            continue
    capture.close()
    all_flags.extend(file_flags)
    output.append({'file': path, 'flags_string': None, 'flags_string_shorten': None})

# Generate unique alphabet list
alphabet = unique_alphabet(all_flags)

# Convert flags to string for each file and create shortened string
for i, path in enumerate(pcap_paths):
    file_flags = []
    capture = pyshark.FileCapture(path, only_summaries=False, use_json=True)
    for packet in capture:
        try:
            if 'TCP' in packet:
                flags = packet.tcp.flags
                if flags:
                    file_flags.append(flags)
        except AttributeError:
            continue
    capture.close()
    flags_string = flags_to_string(file_flags, alphabet)
    output[i]['flags_string'] = flags_string
    output[i]['flags_string_shorten'] = shorten_flags_string(flags_string)

# Create MinHash for each shortened flags string
minhashes = [create_minhash(item['flags_string_shorten']) for item in output if 'flags_string_shorten' in item]

# Compare similarities (this example compares each pair)
for i in range(len(minhashes)):
    for j in range(i + 1, len(minhashes)):
        similarity = minhashes[i].jaccard(minhashes[j])
        print(f"Similarity between file {output[i]['file']} and {output[j]['file']}: {similarity}")

alphabet_conversion = {flag: i for i, flag in enumerate(alphabet)}
output.append({'alphabet_conversion': alphabet_conversion})

# Save the output
with open('output33.json', 'w') as out_file:
    json.dump(output, out_file, indent=4)

print("Output JSON created with flag strings and shortened strings for each pcap file, and alphabet conversion.")
