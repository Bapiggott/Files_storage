import json

def read_json(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def unique_alphabet(flags):
    return sorted(set(flags))

def flags_to_string(flags, alphabet):
    return ''.join([str(alphabet.index(flag)) if flag in alphabet else '' for flag in flags])

# Example file paths - replace with actual paths
file_paths = ['file1.json', 'file2.json', 'file3.json']

all_flags = []
output = []

# Read each file and extract flags
for path in file_paths:
    data = read_json(path)
    file_flags = [item['flags'] for item in data if item['flags'] is not None]
    all_flags.extend(file_flags)
    output.append({'file': path, 'flags_string': None})

# Generate unique alphabet list
alphabet = unique_alphabet(all_flags)

# Convert flags to string for each file
for i, path in enumerate(file_paths):
    data = read_json(path)
    file_flags = [item['flags'] for item in data if item['flags'] is not None]
    flags_string = flags_to_string(file_flags, alphabet)
    output[i]['flags_string'] = flags_string

# Add the alphabet conversion to the output
alphabet_conversion = {flag: i for i, flag in enumerate(alphabe
output.append({'alphabet_conversion': alphabet_conversion})

# Save to output JSON
with open('output1.json', 'w') as out_file:
    json.dump(output, out_file, indent=4)

print("Output JSON created with flag strings for each file and alphabet conversion.")
