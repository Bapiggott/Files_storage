import os
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import re
from multiprocessing import Pool
import concurrent.futures
import ijson
import argparse
import math
import pandas as pd
import json
import concurrent.futures


def flip_flags(flags):
    flag_map = {
        'F': 0,
        'S': 1,
        'R': 2,
        'P': 3,
        'A': 4,
        'U': 5,
        'E': 6,
        'C': 7
    }

    # Initialize the result_flags list with empty strings
    result_flags = ['', '', '', '', '', '', '', '']

    # Assign the characters to their respective positions in result_flags
    for flag in flags:
        if flag in flag_map:
            result_flags[flag_map[flag]] = flag

    # Filter out the empty strings and join the non-empty flags into a single string
    corrected_flags = ''.join(filter(lambda x: x != '', result_flags))

    return corrected_flags


def correct_flags_in_json(json_file):
    # Read the JSON data from the file
    with open(json_file, 'r') as f:
        data = json.load(f)

    # Correct the "flags" field in each entry of the JSON data
    for entry in data:
        if 'flags' in entry:
            entry['flags'] = flip_flags(entry['flags'])

    # Save the modified JSON back to the file
    with open(json_file, 'w') as f:
        json.dump(data, f, indent=2)


def move_json(json_path, destination_dir, chunk_size=1024 * 1024 * 10):  # 10 MB chunks by default
    filename = os.path.basename(json_path)
    destination_path = os.path.join(destination_dir, filename)

    # Check if the file already exists in the destination directory
    if not os.path.exists(destination_path):
        with open(json_path, 'rb') as source_file, open(destination_path, 'wb') as dest_file:
            while True:
                chunk = source_file.read(chunk_size)
                if not chunk:
                    break
                dest_file.write(chunk)

        print(f"Moved {filename} to {destination_dir}")
    else:
        print(f"{filename} already exists in {destination_dir}. Skipped.")


def move_json_2(json_path, destination_dir1, destination_dir2, chunk_size=1024 * 1024 * 10):  # 10 MB chunks by default
    filename = os.path.basename(json_path)

    destination_path1 = os.path.join(destination_dir1, filename)
    destination_path2 = os.path.join(destination_dir2, filename)

    # Check if the file already exists in the destination directories
    if not os.path.exists(destination_path1) or not os.path.exists(destination_path2):
        with open(json_path, 'rb') as source_file, open(destination_path1, 'wb') as dest_file1, open(destination_path2,
                                                                                                     'wb') as dest_file2:
            while True:
                print("chunk")
                chunk = source_file.read(chunk_size)
                if not chunk:
                    break
                dest_file1.write(chunk)
                dest_file2.write(chunk)

        print(f"Moved {filename} to {destination_dir1} and {destination_dir2}")
    else:
        print(f"{filename} already exists in {destination_dir1} and {destination_dir2}. Skipped.")


def process_json5(json_path):
    print(f"working on: {json_path}")
    with open(json_path, 'r') as file:
        # Create a JSON decoder
        true_statement = True
        decoder = json.JSONDecoder()
        index_i = 0

        # Initialize an empty string to accumulate partial JSON content
        partial_json = ''
        prev_chunk = ''
        while true_statement:
            print(f"itereation {index_i} for file: {json_path}")
            index_i += 1
            chunk = file.read(496)  # Read a chunk of the file
            if not chunk:
                print("not chunk")
                break  # End of file

            partial_json += chunk + prev_chunk
            prev_chunk = chunk
            words = partial_json.split()
            # words = partial_json.read().split()
            try:
                # Try to decode the JSON content in the accumulated string
                # print("--\n\n")
                # print(words)
                # Process the decoded JSON object
                for i, word in enumerate(words):
                    if '"sll:ethertype:ip:' in word:
                        print(word)
                        if "udp:data" in word:
                            move_json(json_path, directory_protocol[1])
                            true_statement = False
                            break
                        elif "udp:mavlink_proto" in word:
                            print("mav/")
                            move_json_2(json_path, directory_protocol[2], directory_protocol[1])
                            # move_json(json_path, directory_protocol[1])
                            true_statement = False
                            break
                        elif "tcp:data" in word or "\"sll:ethertype:ip:tcp\"" in word:
                            print("tcp/")
                            move_json(json_path, directory_protocol[0])
                            true_statement = False
                            break

            except json.JSONDecodeError as e:
                print(f"JSONDecodeError: {e}")
                pass
    print(f"Finished: {json_path}\n")


def process_files(target_directory, json_files):
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=5) as executor:  # ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(process_json, os.path.join(target_directory, file)): file for file in
                   json_files}  # was process_json here

        # Wrap tqdm around as_completed to create a progress bar
        for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc="Processing JSON files"):
            file = futures[future]
            try:
                future.result()  # Wait for the result, or raise an exception if an error occurred in the thread
                print(f"Finished: {file}")
            except Exception as e:
                print(f"Error processing {file}: {e}")


def run_move_jsons(target_directory):
    delete_empty_json_files(target_directory)

    for directory in directory_protocol:
        if not os.path.exists(directory):
            os.makedirs(directory)
    print(f"protocol directories are created")

    # Get the list of JSON files in the specified directory
    json_files = [file for file in os.listdir(target_directory) if file.endswith(".json")]

    # for file in json_files:
    # json_path = os.path.join(target_directory, file)
    #   print(f"working on: {file}")
    process_files(target_directory, json_files)
    # process_json(json_path)
    #  print(f"finished: {file}")


def process_dict_ml(data_dict, current_frame, prefix=''):
    result = current_frame
    if result is None:
        result = current_frame
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_ml(value, result, prefix=full_key)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            current_frame[key_string] = value

    return result


def process_dict_udp(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_udp(value, prefix=full_key, result=result)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            """if key_string != "payload":
                result[key_string] = value"""
            if key_string not in ["port"]:
                result[key_string] = value

    return result


def delete_empty_json_files(directory):
    for filename in os.listdir(directory):
        if filename.endswith(".json"):
            file_path = os.path.join(directory, filename)
            if os.path.getsize(file_path) == 0:
                print(f"Deleting {filename}")
                os.remove(file_path)


def process_dict_ml_ports(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_ml_ports(value, prefix=full_key, result=result)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            if key_string == "srcport" or key_string == "dstport":
                result[key_string] = value

    return result


def process_dict_tcp(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    valid_key_strings = ["srcport", "dstport", "len", "seq", "ack", "str"]
    wanted_key_strings = ["sport", "dport", "len", "seq", "ack", "flags"]
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_tcp(value, prefix=full_key, result=result)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            if key_string in valid_key_strings:
                index = valid_key_strings.index(key_string)
                if index == 5:
                    matches = re.findall(r'\b[A-Z]+\b', value)
                    result[wanted_key_strings[5]] = matches[0]
                else:
                    result[wanted_key_strings[index]] = value

    return result


def filtered_jsons1(input_directory, output_directory):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_{filename}")
            remove_incomplete_package(input_file_path, f'{input_file_path}_temp.json')
            remove_trailing_comma(f'{input_file_path}_temp.json', input_file_path)
            delete_file(f'{input_file_path}_temp.json')
            # Read the original JSON file
            with open(input_file_path, 'r') as file:
                print(input_file_path)
                data_list = json.load(file)

            filtered_data_list = []

            for item in data_list:
                if input_directory == directory_protocol[1]:
                    mavlink_proto_dict = item["_source"]["layers"]["udp"]
                    # print("filtering for UDP")
                    filtered_data = process_dict_udp(mavlink_proto_dict)
                elif input_directory == directory_protocol[0]:
                    mavlink_proto_dict = item["_source"]["layers"]["tcp"]
                    filtered_data = process_dict_tcp(mavlink_proto_dict)
                    # print("filtering for TCP")
                elif input_directory == directory_protocol[2]:
                    mavlink_proto_dict = item["_source"]["layers"]["udp"]
                    # print("filtering for UDP")
                    results = process_dict_ml_ports(mavlink_proto_dict)
                    # filtered_data_list.append(filtered_data)
                    mavlink_proto_dict = item["_source"]["layers"]["mavlink_proto"]
                    filtered_data = process_dict_ml(mavlink_proto_dict, results)
                    # print("filtering for Mavlink")
                else:
                    print("no protocol directory, something went wrong")
                    mavlink_proto_dict = "."
                    filtered_data = process_dict_ml(mavlink_proto_dict)
                # filtered_data = process_dict(mavlink_proto_dict)

                filtered_data_list.append(filtered_data)

            with open(output_file_path, 'w') as output_file:
                json.dump(filtered_data_list, output_file, indent=4)

            print(f"Filtered data from {filename} has been saved to: {output_file_path}")


def filtered_jsons_chunked(input_directory, output_directory):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_{filename}")
            remove_incomplete_package(input_file_path, f'{input_file_path}_temp.json')
            remove_trailing_comma(f'{input_file_path}_temp.json', input_file_path)
            delete_file(f'{input_file_path}_temp.json')

            # Process the large JSON file in chunks
            process_large_json(input_file_path, output_file_path)


def process_large_json(input_file_path, output_file_path):
    # Read the original JSON file using ijson for incremental processing
    with open(input_file_path, 'rb') as file:
        print(input_file_path)

        # Create an ijson parser
        parser = ijson.parse(file)

        # Initialize variables
        filtered_data_list = []
        mavlink_proto_dict = None
        results = None

        # Iterate over JSON elements in chunks
        for prefix, event, value in parser:
            if event == 'start_map' and value == 'udp':
                # Detect the start of the "udp" map
                parser, mavlink_proto_dict = ijson.parse(file), None
            elif mavlink_proto_dict is not None:
                # Process "udp" map content
                if event == 'map_key' and value == 'udp_field':  # replace 'udp_field' with the actual key
                    mavlink_proto_dict = value
                    # print("filtering for UDP")
                    filtered_data = process_dict_udp(mavlink_proto_dict)
                    filtered_data_list.append(filtered_data)

        # Write filtered data to the output file
        with open(output_file_path, 'w') as output_file:
            json.dump(filtered_data_list, output_file, indent=4)

        print(f"Filtered data from {input_file_path} has been saved to: {output_file_path}")


def read_json_chunks(file, max_chunk_size=4096):
    buffer = ''
    print("hiiii")
    for line in file:
        buffer += line
        if buffer.count('{') == buffer.count('}'):
            # The number of opening and closing braces is equal, indicating a complete JSON object
            yield buffer
            buffer = ''
        elif len(buffer) > max_chunk_size:
            # The buffer has exceeded the maximum chunk size, indicating a potentially large JSON object
            # closest_comma = buffer.rfind(',', 0, max_chunk_size)
            closest_bracket = max(buffer.rfind(']', 0, max_chunk_size), buffer.rfind('}', 0, max_chunk_size))

            yield buffer[:closest_bracket + 1]
            buffer = buffer[closest_bracket + 1:]

    # Yield any remaining buffer
    if buffer:
        yield buffer


def chunked_json_load(file, chunk_size=1024):
    decoder = json.JSONDecoder()
    buffer = ""
    while True:
        chunk = file.read(chunk_size)
        if not chunk:
            break
        buffer += chunk
        pos = 0
        while True:
            try:
                obj, pos = decoder.raw_decode(buffer, pos)
                yield obj
            except json.JSONDecodeError:
                # Incomplete JSON in the chunk, read more data
                break
        buffer = buffer[pos:]


def chunked(iterable, chunk_size):
    """Yield successive n-sized chunks from iterable."""
    for i in range(0, len(iterable), chunk_size):
        yield iterable[i:i + chunk_size]


def load_partial_json1(file_path, min, max):
    with open(file_path, 'r') as file:
        i = min
        current_json = ""

        for i, line in enumerate(file):
            line = line.strip()

            if not line:
                continue

            current_json += line

            try:
                data = json.loads(current_json)
                print(f'data[{i}] = {data}')
                current_json = ""
                if max is not None and i >= max:
                    return data
            except json.JSONDecodeError:
                print(line)
                pass


def load_partial_json(file_path, start_line, end_line):
    with open(file_path, 'r') as file:
        # Skip lines until reaching the start line
        for _ in range(start_line - 1):
            file.readline()
        # print("a")
        # Load and process lines from start_line to end_line
        result = []
        for line_number in range(start_line, end_line + 1):
            line = file.readline()
            if not line:
                break  # End of file reached
            print("b")
            try:
                data = json.loads(line)
                result.append(data)
            except json.decoder.JSONDecodeError as e:
                print(f"Error decoding JSON at line {line_number}: {e}")

            print("c")
        return result


def load_partial_json2(file_path, min, max):
    with open(file_path, 'r') as file:
        i = min
        for i, line in enumerate(file):
            line = line.strip()  # Remove leading and trailing whitespaces
            if not line:
                continue  # Skip empty lines

            if i == 0 and line == '[':
                continue
            data = json.loads(line)
            print(f'date[i] = {data[i]}')
            if max is not None and i >= max:
                return data

    raise KeyError(f"The max '{max}' is not present in the first {max} lines of the JSON file.")


def count_lines(file_path):
    with open(file_path, 'r') as file:
        line_count = sum(1 for line in file)
        print(f"line count: {line_count}")
    return line_count


def filtered_jsons_test(input_directory, output_directory, chunk_size=100):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_array_{filename}")

            with open(input_file_path, 'rb') as file:
                print(input_file_path)
                filtered_data_list = []

                # Use the array version of ijson.items
                jsonobj = ijson.items(file, 'item._source.layers.udp', use_float=True)

                # Wrap the result in a list to create a JSON array
                filtered_data_list = list(jsonobj)
                for item in filtered_data_list:
                    filtered_data = process_dict_udp(item)

                with open(output_file_path, 'a') as output_file:
                    # Write the entire array to the output file
                    json.dump(filtered_data, output_file, indent=4)
                    output_file.write('\n')


def filtered_jsons_array(input_directory, output_directory, chunk_size=100):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_array_{filename}")
            with open(input_file_path, 'rb') as file:
                print(input_file_path)
                filtered_data_list = []
                jsonobj = ijson.items(file, 'item._source.layers.udp', use_float=True)
                for item in jsonobj:
                    try:
                        mavlink_proto_dict = item
                        filtered_data = process_dict_udp(mavlink_proto_dict)
                        filtered_data_list.append(filtered_data)
                    except Exception as ex:
                        print(item)
                        continue

                # Write the entire list to the output file as a JSON array
                with open(output_file_path, 'a') as output_file:
                    json.dump(filtered_data_list, output_file, indent=4)
                    output_file.write('\n')


def filtered_jsons(input_directory, output_directory, Context_size, type_index, chunk_size=100):
    # Create the output directory if it doesn't exist
    make_dir(output_directory)
    item_source = ['tcp', 'udp', 'mavlink_proto']
    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_comma_{filename}")
            with open(input_file_path, 'rb') as file:
                print(input_file_path)
                with open(output_file_path, 'a') as output_file:
                    output_file.write('[\n')
                    jsonobj = ijson.items(file, f'item._source.layers.{item_source[type_index]}', use_float=True)
                    first_item = True  # Flag to track if it's the first item
                    counter = 0
                    if item_source[type_index] == 'tcp':
                        for item in jsonobj:
                                if not first_item:
                                    output_file.write(",\n")
                                try:
                                    mavlink_proto_dict = item  # ["_source"]["layers"]["tcp"]
                                    filtered_data = process_dict_tcp(mavlink_proto_dict)
                                    if counter == 0:
                                        counter = 1
                                        for _ in range(Context_size):
                                            try:
                                                new_message = {key: None for key in filtered_data.keys()}
                                                if first_item:
                                                    first_item = False
                                                json.dump(new_message, output_file, indent=4)
                                                output_file.write(',\n')

                                            except Exception as e:
                                                print(f"Error processing {file}: {e}")
                                            except Exception as ex:
                                                print(item)
                                                continue
                                    first_item = False
                                    json.dump(filtered_data, output_file, indent=4)
                                except Exception as ex:
                                    print(item)
                                    continue
                        #with open(output_file_path, 'a') as output_file:
                        output_file.write("\n]")
                    elif item_source[type_index] == 'mavlink_proto':
                        for item in jsonobj:
                                if not first_item:
                                    output_file.write(",\n")
                                try:
                                    mavlink_proto_dict = item  # ["_source"]["layers"]["tcp"]
                                    filtered_data = process_dict_udp(mavlink_proto_dict)
                                    if counter == 0:
                                        counter = 1
                                        for _ in range(Context_size):
                                            try:
                                                new_message = {key: None for key in filtered_data.keys()}
                                                if first_item:
                                                    first_item = False
                                                json.dump(new_message, output_file, indent=4)
                                                output_file.write(',\n')

                                            except Exception as e:
                                                print(f"Error processing {file}: {e}")
                                            except Exception as ex:
                                                print(item)
                                                continue
                                    first_item = False
                                    json.dump(filtered_data, output_file, indent=4)
                                except Exception as ex:
                                    print(item)
                                    continue
                        #with open(output_file_path, 'a') as output_file:
                        output_file.write("\n]")
                    elif item_source[type_index] == 'udp':
                        for item in jsonobj:
                                if not first_item:
                                    output_file.write(",\n")
                                try:
                                    mavlink_proto_dict = item
                                    results = process_dict_udp(mavlink_proto_dict)
                                    mavlink_proto_dict = item
                                    filtered_data = process_dict_ml(mavlink_proto_dict, results)
                                    if counter == 0:
                                        counter = 1
                                        for _ in range(Context_size):
                                            try:
                                                new_message = {key: None for key in filtered_data.keys()}
                                                if first_item:
                                                    first_item = False
                                                json.dump(new_message, output_file, indent=4)
                                                output_file.write(',\n')

                                            except Exception as e:
                                                print(f"Error processing {file}: {e}")
                                            except Exception as ex:
                                                print(item)
                                                continue
                                    first_item = False
                                    json.dump(filtered_data, output_file, indent=4)
                                except Exception as ex:
                                    print(item)
                                    continue
                        #with open(output_file_path, 'a') as output_file:
                        output_file.write("\n]")


def filtered_jsons_all(input_directory, Context_size, chunk_size=100):
    for index in range(len(directory_protocol)):
        make_dir(directory_protocol[index])
    item_source = ['tcp', 'udp', 'mavlink_proto']
    for filename in os.listdir(input_directory):
        for index in range(len(protocol_vector)):
            if filename.endswith(".json") and (protocol_vector[index] in filename):
                input_file_path = os.path.join(input_directory, filename)
                output_file_path = os.path.join(directory_protocol[index], f"filtered_comma_{filename}")
                with open(input_file_path, 'rb') as file:
                    print(input_file_path)
                    with open(output_file_path, 'a') as output_file:
                        output_file.write('[\n')
                        jsonobj = ijson.items(file, f'item._source.layers.{item_source[index]}', use_float=True)
                        first_item = True  # Flag to track if it's the first item
                        counter = 0
                        if item_source[index] == 'tcp':
                            for item in jsonobj:
                                    if not first_item:
                                        output_file.write(",\n")
                                    try:
                                        mavlink_proto_dict = item  # ["_source"]["layers"]["tcp"]
                                        filtered_data = process_dict_tcp(mavlink_proto_dict)
                                        if counter == 0:
                                            counter = 1
                                            for _ in range(Context_size):
                                                try:
                                                    new_message = {key: None for key in filtered_data.keys()}
                                                    if first_item:
                                                        first_item = False
                                                    json.dump(new_message, output_file, indent=4)
                                                    output_file.write(',\n')

                                                except Exception as e:
                                                    print(f"Error processing {file}: {e}")
                                                except Exception as ex:
                                                    print(item)
                                                    continue
                                        first_item = False
                                        json.dump(filtered_data, output_file, indent=4)
                                    except Exception as ex:
                                        print(item)
                                        continue
                            #with open(output_file_path, 'a') as output_file:
                            output_file.write("\n]")
                            """elif item_source[index] == 'mavlink_proto':
                            for item in jsonobj:
                                    if not first_item:
                                        output_file.write(",\n")
                                    try:
                                        mavlink_proto_dict = item  # ["_source"]["layers"]["tcp"]
                                        filtered_data = process_dict_udp(mavlink_proto_dict)
                                        if counter == 0:
                                            counter = 1
                                            for _ in range(Context_size):
                                                try:
                                                    new_message = {key: None for key in filtered_data.keys()}
                                                    if first_item:
                                                        first_item = False
                                                    json.dump(new_message, output_file, indent=4)
                                                    output_file.write(',\n')

                                                except Exception as e:
                                                    print(f"Error processing {file}: {e}")
                                                except Exception as ex:
                                                    print(item)
                                                    continue
                                        first_item = False
                                        json.dump(filtered_data, output_file, indent=4)
                                    except Exception as ex:
                                        print(item)
                                        continue
                            #with open(output_file_path, 'a') as output_file:
                            output_file.write("\n]")"""
                        elif item_source[index] == 'udp':
                            for item in jsonobj:
                                    if not first_item:
                                        output_file.write(",\n")
                                    try:
                                        mavlink_proto_dict = item
                                        results = process_dict_udp(mavlink_proto_dict)
                                        mavlink_proto_dict = item
                                        filtered_data = process_dict_ml(mavlink_proto_dict, results)
                                        if counter == 0:
                                            counter = 1
                                            for _ in range(Context_size):
                                                try:
                                                    new_message = {key: None for key in filtered_data.keys()}
                                                    if first_item:
                                                        first_item = False
                                                    json.dump(new_message, output_file, indent=4)
                                                    output_file.write(',\n')

                                                except Exception as e:
                                                    print(f"Error processing {file}: {e}")
                                                except Exception as ex:
                                                    print(item)
                                                    continue
                                        first_item = False
                                        json.dump(filtered_data, output_file, indent=4)
                                    except Exception as ex:
                                        print(item)
                                        continue
                            #with open(output_file_path, 'a') as output_file:
                            output_file.write("\n]")


def filtered_jsons_the_one(input_directory, output_directory, chunk_size=100):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)
            output_file_path = os.path.join(output_directory, f"filtered_comma_{filename}")

            with open(input_file_path, 'rb') as file:
                print(input_file_path)
                filtered_data_list = []

                jsonobj = ijson.items(file, 'item._source.layers.udp', use_float=True)

                first_item = True  # Flag to track if it's the first item

                for item in jsonobj:
                    try:
                        mavlink_proto_dict = item  # ["_source"]["layers"]["tcp"]
                        filtered_data = process_dict_udp(mavlink_proto_dict)

                        with open(output_file_path, 'a') as output_file:
                            # Add a comma before writing the JSON object (except for the first item)
                            if not first_item:
                                output_file.write(',\n')

                            json.dump(filtered_data, output_file, indent=4)
                            output_file.write('\n')

                            # Set the flag to False after processing the first item
                            first_item = False
                    except Exception as ex:
                        print(item)
                        continue


def convert_pcap_to_json(input_pcap, output_json):
    try:
        tshark_command = f'tshark -r "{input_pcap}" -T json > "{output_json}"'
        subprocess.run(tshark_command, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error converting {input_pcap}: {e}")


def pcaps2jsons(output_directory):
    # Create the output directory if it doesn't exist
    input_directory = "processed_pcaps" 
    make_dir(output_directory)

    # Get a list of all the pcap files in the input directory
    pcap_files = [file for file in os.listdir(input_directory) if file.endswith(".pcap")]

    # Create a progress bar to track the conversion process
    with tqdm(total=len(pcap_files), desc="Converting pcaps to json") as pbar, \
            ThreadPoolExecutor() as executor:
        # Use ThreadPoolExecutor to parallelize the conversion process
        futures = []
        for pcap_file in pcap_files:
            input_pcap_path = os.path.join(input_directory, pcap_file)
            output_json_file = os.path.join(output_directory, f"{pcap_file}.json")
            futures.append(executor.submit(convert_pcap_to_json, input_pcap_path, output_json_file))

        # Wait for all tasks to complete
        for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc="Processing"):
            future.result()
            pbar.update(1)

    print("Conversion complete.")


def combine_json_files(input_directory, output_combined_file, num_null_messages):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        output_file.write("[\n")  # Start the JSON array

        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Add null messages to the start of each section
                    message = file_content[0].keys()
                    for _ in range(num_null_messages):
                        new_messages = {
                            key: None  # Set each key to None for "n/a"
                            for key in message
                        }
                        new_messages["filename"] = filename
                        file_content.insert(0, new_messages)

                    # Write each JSON object in the section
                    for i, content in enumerate(file_content):
                        # Add the filename field to each message
                        content["filename"] = filename

                        json.dump(content, output_file, indent=4)
                        if i < len(file_content) - 1:
                            output_file.write(',')  # Add a comma after each item except the last one
                            output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")

        output_file.write("]")  # End the JSON array


def combine_json_files_new(input_directory, output_combined_file, num_null_messages):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        output_file.write("[\n")  # Start the JSON array

        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Add null messages to the start of each section
                    message = file_content[0].keys()
                    for _ in range(num_null_messages):
                        new_messages = {
                            key: None  # Set each key to None for "n/a"
                            for key in message
                        }
                        new_messages["filename"] = filename
                        file_content.insert(0, new_messages)

                    # Write each JSON object in the section
                    for i, content in enumerate(file_content):
                        # Add the filename field to each message
                        content["filename"] = filename

                        json.dump(content, output_file, indent=4)
                        if i < len(file_content) - 1:
                            output_file.write(',')  # Add a comma after each item except the last one
                            output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")

        output_file.write("]")  # End the JSON array


def combine_json_files_current(input_directory, output_combined_file, num_null_messages):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Add null messages to the start of each section
                    message = file_content[0].keys()
                    for _ in range(num_null_messages):
                        new_messages = {
                            key: None  # Set each key to None for "n/a"
                            for key in message
                        }
                        new_messages["filename"] = filename
                        file_content.insert(0, new_messages)

                    # Write each JSON object in the section
                    for content in file_content:
                        # Add the filename field to each message
                        content["filename"] = filename

                        json.dump(content, output_file, indent=4)
                        output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")


def combine_json_files_9(input_directory, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)


                    # Write each JSON object in the section
                    for content in file_content:
                        # Add the filename field to each message
                        content["filename"] = filename

                        json.dump(content, output_file, indent=4)
                        output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")



def combine_json_files_1(input_directory, output_combined_file, num_null_messages):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Add null messages to the start of each section
                    for _ in range(num_null_messages):
                        new_messages = {
                            "filename": filename,
                            "data": {
                                key: None  # Set each key to None for "n/a"
                                for key in file_content[0].keys()
                            }
                        }
                        file_content.insert(0, new_messages)

                    # Write each JSON object in the section
                    for content in file_content:
                        json.dump(content, output_file, indent=4)
                        output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")


def combine_json_files_works(input_directory, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Write each JSON object in the section
                    for content in file_content:
                        # Add the filename field to each message
                        content["filename"] = filename

                        json.dump(content, output_file, indent=4)
                        output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")


def combine_json_files_works(input_directory, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    with open(output_combined_file, 'w') as output_file:
        for filename in os.listdir(input_directory):
            if filename.endswith(".json"):
                input_file_path = os.path.join(input_directory, filename)

                try:
                    with open(input_file_path, 'r') as f:
                        # Read the entire file as a JSON array
                        file_content = json.load(f)

                    # Write the header for each section

                    # Write each JSON object in the section
                    for content in file_content:
                        json.dump(content, output_file, indent=4)
                        output_file.write('\n')

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file_path}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file_path}: {ex}")


def combine_json_files_kinda_works(input_directory, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    # List to store individual JSON objects
    json_contents = []

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)

            try:
                with open(input_file_path, 'r') as f:
                    # Read the entire file as a JSON array
                    file_content = json.load(f)
                    json_contents.extend(file_content)

            except json.decoder.JSONDecodeError as e:
                print(f"Error decoding JSON in file {input_file_path}: {e}")
                # Handle the error, e.g., skip the file or take appropriate action

            except Exception as ex:
                print(f"Error reading file {input_file_path}: {ex}")
                # Handle the error, e.g., skip the file or take appropriate action

    # Write the combined content to the output file as a JSON array
    with open(output_combined_file, 'w') as output_file:
        json.dump(json_contents, output_file, indent=4)


def combine_json_files_og(input_directory, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content

    # List to store individual JSON file content
    json_contents = []

    for filename in os.listdir(input_directory):
        if filename.endswith(".json"):
            input_file_path = os.path.join(input_directory, filename)

            try:
                with open(input_file_path, 'r') as f:
                    # Read lines from the file
                    lines = f.readlines()

                    for line in lines:
                        try:
                            # Load JSON content from each line
                            file_content = json.loads(line)
                            json_contents.append(file_content)
                        except json.decoder.JSONDecodeError as e:
                            print(f"Error decoding JSON in file {input_file_path}: {e}")
                            # Handle the error, e.g., skip the line or take appropriate action

            except Exception as ex:
                print(f"Error reading file {input_file_path}: {ex}")
                # Handle the error, e.g., skip the file or take appropriate action

    # Combine JSON content from all files
    combined_content = []
    for content in json_contents:
        combined_content.extend(content)

    # Write the combined content to the output file
    with open(output_combined_file, 'w') as output_file:
        json.dump(combined_content, output_file, indent=4)


def combine_json_files1(input_directory, output_file, ):
    directory_path = input_directory

    combined_data = {}

    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):
            with open(os.path.join(directory_path, filename)) as f:
                json_content = json.load(f)
                # Extract the original title from the filename (without the .json extension)
                title = os.path.splitext(filename)[0]
                combined_data[title] = json_content

    output_combined_file = output_file

    with open(output_combined_file, 'w') as f:
        json.dump(combined_data, f, indent=2)

    print(f"{output_combined_file} files combined successfully!")


def add_na_messages(json_data, Context_size):
    for section_data in json_data:
        new_messages = {
            key: None  # Set each key to None for "n/a"
            for key in section_data.keys()
        }
        section_data.insert(0, new_messages)
    return json_data



def add_na_messages_og(json_data, Context_size):
    for section_name, section_data in json_data.items():
        new_messages = [
            {
                key: None  # Set each key to None for "n/a"
                for key in section_data[0].keys()
            }
            for _ in range(Context_size + 1)
        ]
        json_data[section_name] = new_messages + section_data
    return json_data


def add_na_messages_ijson(input_file_path, output_file_path, Context_size):
    counter = 0
    with open(input_file_path, 'rb') as file:
        print(input_file_path)

        jsonobj = ijson.items(file, 'item', use_float=True)

        for item in jsonobj:
            try:
                if counter == 0:
                    counter = 1
                    for _ in range(Context_size):
                        try:
                            new_message = {key: None for key in item.keys()}
                            """new_messages = [
                                {
                                    key: None  # Set each key to None for "n/a"
                                    for key in item.keys()
                                }
                                for _ in range(Context_size + 1)
                            ]
                            item = new_messages + item"""
                            with open(output_file_path, 'a') as output_file:
                                # Add a comma before writing the JSON object (except for the first item)
                                json.dump(new_message, output_file, indent=4)
                                output_file.write('\n')
                        except Exception as e:
                            print(f"Error processing {file}: {e}")
                        except Exception as ex:
                            print(item)
                            continue

                with open(output_file_path, 'a') as output_file:
                    # Add a comma before writing the JSON object (except for the first item)
                    json.dump(item, output_file, indent=4)
                    output_file.write('\n')
            except Exception as e:
                print(f"Error processing {file}: {e}")
            except Exception as ex:
                print(item)
                continue


def add_na_messages_ijson_(input_file_path, output_file_path, Context_size):
    with open(input_file_path, 'r') as input_file, open(output_file_path, 'w') as output_file:
        # Create an ijson parser
        parser = ijson.parse(input_file)

        # Iterate over the JSON structure
        for prefix, event, value in parser:
            if event == 'start_map':
                # When starting a new map (object), add null messages to the beginning
                new_messages = [
                    {key: None for key in value.keys()}  # Set each key to None for "n/a"
                    for _ in range(Context_size + 1)
                ]
                json.dump(new_messages, output_file)
                output_file.write('\n')

            # Write the original event and value to the output file
            if event and value is not None:
                json.dump({event: value}, output_file)
                output_file.write('\n')


def convert_sets_to_lists(obj):
    if isinstance(obj, dict):
        print("convert set to list finished")
        return {key: convert_sets_to_lists(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        print("convert set to list finished")
        return [convert_sets_to_lists(element) for element in obj]
    elif isinstance(obj, set):
        print("convert set to list finished")
        return list(obj)
    else:
        return obj


def create_sliding_window(content, window_size):
    sliding_window_data = []

    window = []

    for message in content:
        window.append(message)  # Add the current message to the end of the window
        window = window[-window_size:]  # Truncate the window to the specified size

        if len(window) == window_size:  # Only append to output if the window is at the set size
            c_data = window[:-2]
            q_data = window[-2]
            a_data = window[-1]

            sliding_window_data.append({"Context": c_data, "Question": q_data, "Answer": a_data})

    print("Created sliding window")
    return sliding_window_data


def tcp_case(entries, output_entries, previous_flag, previous_source, previous_destination):
    for entry in entries:
        if 'flags' in entry:
            flags = entry['flags']
            source = entry['sport']
            destination = entry['dport']

            if flags is None or flags != previous_flag:
                output_entries.append(entry)
                previous_flag = flags
                previous_source = source
                previous_destination = destination
            if source != previous_source or destination != previous_destination:
                output_entries.append(entry)
                previous_flag = flags
                previous_source = source
                previous_destination = destination
            else:
                if output_entries:
                    output_entries[-1] = entry  # Replace the last entry with the current one

    return output_entries


def udp_case(entries, output_entries, previous_flag, previous_source, previous_destination):
    for entry in entries:
        if 'srcport' in entry:
            source = entry['srcport']
            destination = entry['dstport']
            flags = entry["port"]

            if flags is None or flags != previous_flag:
                output_entries.append(entry)
                previous_flag = flags
                previous_source = source
                previous_destination = destination

            if source != previous_source or destination != previous_destination:
                output_entries.append(entry)
                previous_source = source
                previous_destination = destination
            else:
                if output_entries:
                    output_entries[-1] = entry  # Replace the last entry with the current one

    return output_entries


def mvl_case(entries, output_entries, previous_flag, previous_source, previous_destination):
    for entry in entries:
        if 'srcport' in entry:
            source = entry['srcport']
            destination = entry['dstport']
            flags = entry["magic"]

            if flags is None or flags != previous_flag:
                output_entries.append(entry)
                previous_flag = flags
                previous_source = source
                previous_destination = destination

            if source != previous_source or destination != previous_destination:
                output_entries.append(entry)
                previous_source = source
                previous_destination = destination
            else:
                if output_entries:
                    output_entries[-1] = entry  # Replace the last entry with the current one

    return output_entries


def default(entries, output_entries, previous_flag, previous_source, previous_destination):
    result = "This is the default case"
    output_entries.append(result)
    return output_entries


def switch_case(case, entries, output_entries, previous_flag, previous_source, previous_destination):
    switch_dict = {
        0: tcp_case,
        1: udp_case,
        2: mvl_case,
    }

    # return switch_dict.get(index, default)(entries, output_entries, previous_flag, previous_source, previous_destination)
    return switch_dict.get(case, default)(entries, output_entries, previous_flag, previous_source,
                                          previous_destination)


def process_data(entries, protocol_index):
    output_entries = []
    previous_flag = None
    previous_source = None
    previous_destination = None

    output_entries = switch_case(protocol_index, entries, output_entries, previous_flag, previous_source,
                                 previous_destination)

    return output_entries

def create_sliding_window_1(content, window_size):
    sliding_window_data = []

    window = []

    for message in content:
        window.append(message)  # Add the current message to the end of the window
        window = window[-window_size:]  # Truncate the window to the specified size

        if len(window) == window_size:  # Only append to output if the window is at the set size
            c_data = window[:-2]
            q_data = window[-2]
            a_data = window[-1]

            sliding_window_data.append({"Context": c_data, "Question": q_data, "Answer": a_data})

    print("Created sliding window")


def create_sliding_window_for_directory(directory_path, output_file_path, window_size, protocol_type):
    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):  # assuming the files are JSON
            file_path = os.path.join(directory_path, filename)
            create_sliding_window_2(file_path, output_file_path, window_size, protocol_type)

def create_sliding_window_2(file, output_file_path, window_size, protocol_type):
    window = []
    temp_window = []
    counter = 0
    output_file_path = output_file_path + '/' + file.replace(".json", f"_slidding_window_{protocol_type}.json")
    with open(file, 'rb') as data:
        print(file)
        with open(output_file_path, 'a+') as output_file:
            jsonobj = ijson.items(data, 'item')
            # output_file.write('[\n')
            i = 0
            counter = 0
            '''for _ in jsonobj:
                counter += 1
            print(f'Amount of items: {counter}')'''
            jsonobj1 = ijson.items(data, 'item')
            first_item = True
            for item in jsonobj1:
                # print(item)
                sliding_window_data = []
                try:
                    window.append(item)
                    window = window[-window_size:]

                    if len(window) == window_size:
                        c_data = window[:-2]
                        q_data = window[-2]
                        a_data = window[-1]
                        sliding_window_data.append({"Context": c_data, "Question": q_data, "Answer": a_data})
                        json_string = json.dumps(sliding_window_data, indent=4)
                        # Remove the first and last characters (braces)
                        json_string = json_string[1:-1]
                        # print(json_string)
                        # with open(output_file_path, 'a') as output_file:
                        if not first_item:
                            output_file.write(',')
                        else:
                            output_file.write('[\n')
                            first_item = False
                        output_file.write(json_string)
                        # json.dump(sliding_window_data, output_file, indent=4)
                        """if i < counter - 1:
                            output_file.write(',')  # Add a comma after each item except the last one
                            # output_file.write('\n')
                        else:
                            output_file.write(']')
                            print('(])')
                        i += 1"""
                        # print(i)
                        #output_file.write(',')

                except Exception as e:
                    print(f"Error processing item: {e}")
            output_file.write(']')
        print("Created sliding window")

def update_slidingwindow_(input_file, output_combined_files):
    # Assuming output_combined_file is the file where you want to combine the JSON content
    with open(input_file, 'rb') as input:
        with open(output_combined_file, 'w') as output_file:
            output_file.write("[\n")  # Start the JSON array
            jsonobj = ijson.items(input, 'item', use_float=True)
            i = 1
            for item in jsonobj:
                try:
                    json.dump(item, output_file, indent=4)
                    if i < len(jsonobj) - 1:
                        output_file.write(',')  # Add a comma after each item except the last one
                        output_file.write('\n')
                    i += 1

                    # Add a separator between sections
                    output_file.write('\n')

                except json.decoder.JSONDecodeError as e:
                    print(f"Error decoding JSON in file {input_file}: {e}")
                    # Handle the error, e.g., skip the file or take appropriate action

                except Exception as ex:
                    print(f"Error reading file {input_file}: {ex}")
            output_file.write("]")
        #output_file.write("]")  # End the JSON array


def update_slidingwindow(input_file, output_combined_file):
    # Assuming output_combined_file is the file where you want to combine the JSON content
    with open(input_file, 'rb') as input:
        with open(output_combined_file, 'w') as output_file:
            output_file.write("[\n")  # Start the JSON array
            try:
                jsonobj = ijson.items(input, 'item', use_float=True)
                i = 1
                for item in jsonobj:
                    json.dump(item, output_file, indent=4)
                    if i < len(jsonobj) - 1:
                        output_file.write(',')  # Add a comma after each item except the last one
                        output_file.write('\n')
                    i += 1

                    # Add a separator between sections
                    output_file.write('\n')

            except json.decoder.JSONDecodeError as e:
                print(f"Error decoding JSON in file {input_file}: {e}")
                # Handle the error, e.g., skip the file or take appropriate action

            except ijson.common.IncompleteJSONError as e:
                print(f"Incomplete JSON in file {input_file}: {e}")
                # Handle the incomplete JSON, e.g., skip the file or take appropriate action

            except Exception as ex:
                print(f"Error reading file {input_file}: {ex}")

            output_file.write("]")



def finalize_json_og_new(Context_size, index, file):
    window_size = Context_size + 2
    with open(file, "r") as f:
        data = json.load(f)
    sliding_window_data = create_sliding_window_2(data, window_size)
    print("")
    # Convert sets to lists
    sliding_window_data = convert_sets_to_lists(sliding_window_data)
    print("")
    output_file_name = f"sliding_window_size_{protocol_vector[index]}.json"
    with open(output_file_name, 'w') as f:
        json.dump(sliding_window_data, f, indent=2)

    print(f"Sliding window JSON created successfully! Output file: {output_file_name}")


def filtered_jsons_wrapper(args):
    filtered_jsons(*args)


def run_pcap_splitter(pcap_file, output_dir):
    command = f'~/Downloads/pcapplusplus-23.09-ubuntu-22.04-gcc-11.2.0-x86_64/bin/PcapSplitter -f "{pcap_file}" -o "{output_dir}" -m connection'
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"Processed {pcap_file}")
    except subprocess.CalledProcessError as e:
        print(f"Error processing {pcap_file}: {e}")


def process_pcaps(input_directory):
    processed_directory = ["unprocessed_pcaps", "processed_pcaps"]
    for index in range(len(processed_directory)):
        make_dir(processed_directory[index])

    pcap_files = [file for file in os.listdir(input_directory) if file.endswith(".pcap")]

    for pcap_file in pcap_files:
        input_path = os.path.join(input_directory, pcap_file)
        run_pcap_splitter(input_path, processed_directory[1])
        output_path = os.path.join(processed_directory[0], pcap_file)
        shutil.move(input_path, output_path)

    print("All pcap files processed and moved.")


def combine_and_finalize_wrapper(args):
    combine_and_finalize(*args)


def combine_and_finalize(output_directory, protocol_vector, index):
    output_combined_file = f'output_combined{protocol_vector}.json'
    combine_json_files(output_directory, output_combined_file)
    Context_size = 4
    finalize_json(Context_size, index, output_combined_file)


def process_directory(index, element, output_directory):
    make_dir(output_directory)
    filtered_jsons(element, output_directory)
    print(f"Processed index {index}")


def remove_trailing_comma(file_path, output_file, chunk_size=1024 * 1024 * 10):
    with open(file_path, 'r') as source_file:
        with open(output_file, 'w') as dest_file:
            last_brace_index = None
            while True:
                chunk = source_file.read(chunk_size)
                if not chunk:
                    break

                # Find the index of the last '}'
                last_brace_index = chunk.rfind(',')  # }')
                dest_file.write(chunk[:last_brace_index - 1])

            if last_brace_index is not None:
                # Append ']' to the last chunk
                dest_file.write(' }\n]')

    print(f"Removed incomplete packages from {file_path} and saved to {output_file}")


def remove_incomplete_package(file_path, output_file, chunk_size=1024 * 1024 * 10):
    with open(file_path, 'r') as source_file:
        with open(output_file, 'w') as dest_file:
            last_brace_index = None
            while True:
                chunk = source_file.read(chunk_size)
                if not chunk:
                    break

                # Find the index of the last '}'
                last_brace_index = chunk.rfind('"_index"')  # }')
                dest_file.write(chunk[:last_brace_index - 3])

            if last_brace_index is not None:
                # Append ']' to the last chunk
                dest_file.write(']')

    print(f"Removed incomplete packages from {file_path} and saved to {output_file}")


def delete_file(file_path):
    try:
        os.remove(file_path)
        print(f"File '{file_path}' successfully deleted.")
    except OSError as e:
        print(f"Error deleting file '{file_path}': {e}")



def json2csv(filename, directory, protocol_type):
    try:
        # Read the JSON file
        with open(f'{directory}/{filename}', "r") as json_file:
            data = json.load(json_file)

        formatted_data = []

        # Loop through each record in the list
        for record in data:
            formatted_record = {
                "Context": record["Context"],
                "Question": record["Question"],
                "Answer": record["Answer"]
            }
            formatted_data.append(formatted_record)

        # Create a DataFrame from the formatted data
        df = pd.DataFrame(formatted_data)

        # Perform your operations on the DataFrame
        df = df.fillna("")

        text_col = []
        for _, row in df.iterrows():
            prompt = "Provided below is a question detailing key attributes of a UDP packet. Preceding this question is a series of UDP packets, which together form the context. Please continue the sequence by providing the subsequent UDP packet that follows the question, serving as the answer. \n\n"
            question = str(row["Question"])
            context = str(row["Context"])
            answer = str(row["Answer"])

            text = prompt + "### Context:\n" + context + "\n### Question\n" + question + "\n### Answer:\n" + answer

            text_col.append(text)

        df.loc[:, "text"] = text_col

        # Save the DataFrame as CSV
        csv_output = f'csvs_{protocol_type}'
        make_dir(csv_output)
        df.to_csv(f"./csvs_{protocol_type}/{filename}.csv", index=False)
        print(f"Processed file: {filename}")

    except json.JSONDecodeError as e:
        print(f"Error decoding JSON in file {filename}: {e}")

def process_files_json2csv(protocol_type):
    directory = f'./datasets_{protocol_type}/'
    with concurrent.futures.ProcessPoolExecutor() as executor:
        # Process each file concurrently
        futures = [executor.submit(json2csv, filename, directory, protocol_type) for filename in os.listdir(directory) if filename.endswith(".json")]

        # Wait for all futures to complete
        concurrent.futures.wait(futures)


def process_file(file_path):
    temp_file_path = f"{file_path}_temp.json"
    remove_incomplete_package(file_path, temp_file_path)
    remove_trailing_comma(temp_file_path, file_path)
    delete_file(temp_file_path)


def fix_json_format_parallel(directory_protocol, num_processes=6):
    with Pool(num_processes) as pool:
        for i in range(len(directory_protocol)):
            file_paths = [os.path.join(directory_protocol[i], filename) for filename in
                          os.listdir(directory_protocol[i]) if filename.endswith(".json")]
            pool.map(process_file, file_paths)


def read_json_chunks(file, chunk_size=1024):
    while True:
        chunk = file.read(chunk_size)
        if not chunk:
            break
        yield chunk


def divide(size, protocol_type):
        """with open(input_file_path, 'a') as file:
            file.write(']')
            print('added ] to file')"""
        output_dir = f'datasets_{protocol_type}'
        make_dir(output_dir)
        slidding_window_jsons = [file for file in os.listdir(".") if file.endswith(f"_slidding_window_{protocol_type}.pcap")]
        for file in slidding_window_jsons:
            with open(file, 'rb') as file:
                # print(input_file_path)
                first_items = []
                # size = 50000
                total_datasets = 0
                jsonobj = ijson.items(file, 'item', use_float=True)
                total_datasets = sum(1 for _ in jsonobj)
                num_files = math.ceil(total_datasets / size)
                print(f'Total number of entries: {total_datasets}\nTotal number of files that\'ll be created: {num_files}')
                for _ in range(60): # total_datasets):
                    # with open(f'sub_dataset_{index}.json', 'a') as output_file:
                    # output_file.write('[\n')
                    first_items.append(True)
                # num_files = 60
                jsonobj = ijson.items(file, 'item', use_float=True)
                counter = 0
                for item in jsonobj:
                    counter += 1
                    index = counter
                    # for index, item in jsonobj:
                    print(f'index: {index}')
                    try:
                        file_index = index % num_files
                        with open(f'{output_dir}/sub_dataset_{file_index}.json', 'a') as output_file:
                            if not first_items[file_index]:
                                output_file.write(",\n")
                            else: #  first_items[index]:
                                output_file.write('[\n')
                                first_items[file_index] = False
                            json_string = json.dumps(item, indent=4)
                            # json_string = json_string[1:-1]
                            output_file.write(json_string)
                    except Exception as ex:
                        print(ex)
                        continue

                for index in range(num_files):
                    with open(f'{output_dir}/sub_dataset_{index}.json', 'a') as output_file:
                        output_file.write("\n]")


def json2csv_1(protocol_type):
    slidding_window_jsons = [file for file in os.listdir(".") if file.endswith(f"_slidding_window_{protocol_type}.pcap")]
    with open(slidding_window_jsons[0], "r") as json_file:
        data = json.load(json_file)

    formatted_data = []

    # Loop through each record in the list
    for record in data:
        formatted_record = {
            "Context": record["Context"],
            "Question": record["Question"],
            "Answer": record["Answer"]
        }
        formatted_data.append(formatted_record)

    # Create a DataFrame from the formatted data
    df = pd.DataFrame(formatted_data)

    # Perform your operations on the DataFrame
    df = df.fillna("")

    text_col = []
    for _, row in df.iterrows():
        prompt = "Provided below is a question detailing key attributes of a UDP packet. Preceding this question is a series of UDP packets, which together form the context. Please continue the sequence by providing the subsequent UDP packet that follows the question, serving as the answer. \n\n"
        question = str(row["Question"])
        context = str(row["Context"])
        answer = str(row["Answer"])

        text = prompt + "### Context:\n" + context + "\n### Question\n" + question + "\n### Answer:\n" + answer

        text_col.append(text)

    df.loc[:, "text"] = text_col

    # Print or save the DataFrame as needed
    print(df.head())
    df.to_csv(f"{protocol_type}_dataset.csv", index=False)



def analyze_pcap_files(directory):
    input_directory = directory
    output_directory = input_directory

    # Get a list of pcap files in the input directory
    pcap_files = [file for file in os.listdir(input_directory) if file.endswith(".pcap")]

    for pcap_file in pcap_files:
        # Full path of input pcap file
        check = 1
        if all(protocol not in pcap_file for protocol in protocol_vector):
            input_pcap_path = os.path.join(input_directory, pcap_file)

            # Command to run for each pcap file
            command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e tcp.flags"

            # Run the command and capture the output
            result = subprocess.run(command, shell=True, capture_output=True, text=True)

            # Check if the command was successful
            if result.returncode == 0:
                # Access the output as a string
                output_string = result.stdout.strip()

                if output_string:
                    # If the output string is not empty, modify the file name
                    new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[0]}.pcap"
                    print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)
                    check = 0

                    # Move the original pcap file to the output directory
                    output_pcap_path = os.path.join(output_directory, new_file_name)
                    os.rename(input_pcap_path, output_pcap_path)
            else:
                # Handle the case where the command failed
                print(f"Error for {pcap_file}:", result.stderr)
                
            if check:      
                command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e mavlink_proto.magic"
                # Run the command and capture the output
                result = subprocess.run(command, shell=True, capture_output=True, text=True)
                if result.returncode == 0:
                    # Access the output as a string
                    output_string = result.stdout.strip()
                    if output_string:
                        # If the output string is not empty, modify the file name
                        new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[2]}.pcap"
                        print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)
                        check = 0

                        # Move the original pcap file to the output directory
                        output_pcap_path = os.path.join(output_directory, new_file_name)
                        os.rename(input_pcap_path, output_pcap_path)
                else:
                    # Handle the case where the command failed
                    print(f"Error for {pcap_file}:", result.stderr)
            if check:
                command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e udp.srcport"
                # Run the command and capture the output
                result = subprocess.run(command, shell=True, capture_output=True, text=True)
                if result.returncode == 0:
                    # Access the output as a string
                    output_string = result.stdout.strip()
                    if output_string:
                        # If the output string is not empty, modify the file name
                        new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[1]}.pcap"
                        print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)

                        # Move the original pcap file to the output directory
                        output_pcap_path = os.path.join(output_directory, new_file_name)
                        os.rename(input_pcap_path, output_pcap_path)
                    else:
                        # If the output string is empty, keep the original file name
                        print(f"Output String is empty for {pcap_file}. File name remains unchanged:", pcap_file)
                else:
                    # Handle the case where the command failed
                    print(f"Error for {pcap_file}:", result.stderr)



def make_dir(directory_path):
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)


class CaseInsensitiveChoicesAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values.lower())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Converts pcaps into a fine-tuning dataset")
    parser.add_argument("--type", "-T", type=str, choices=["udp", "U", "tcp", "T", "mavlink", "M", "all"], default="U", action=CaseInsensitiveChoicesAction, help="Protocol specification.")
    parser.add_argument("--context", '-C', type=int, default=4, help="Size of context window for dataset")
    parser.add_argument("--input", '-I', type=str, default=".", help="Path to directory with pcap files")
    parser.add_argument("--dataset", '-D', type=int, default="0", help="Size of each dataset, default is all items in one dataset")

    # parser.add_argument("--type", "-T", type=str, choices=["UDP", "U", "TCP", "T", "Mavlink", "M"], default="U", help="Type specification.")
    args = parser.parse_args()
    desired_type = args.type
    context_size = args.context
    path2pcaps = args.input
    dataset_size = args.dataset
    directory_protocol = ["./jsons/Tcp_jsons", "./jsons/Udp_jsons", "./jsons/Mavlink_jsons"]
    protocol_vector = ["tcp", "udp", "mavlink"]
    output_directory_filtered = ["output_filtered_tcp", "output_filtered_udp", "output_filtered_mavlink"]
    jsons_output_directory = "jsons"
    output_combined_file = "output_combined.json"

    #these three below
    # process_pcaps(path2pcaps)
    # analyze_pcap_files('processed_pcaps')
    # pcaps2jsons(jsons_output_directory)
    target_directory = "./jsons"
    # run_move_jsons(target_directory)
    # filtered_jsons(jsons_output_directory, output_directory_filtered[1])
    for index, item in enumerate(protocol_vector):
        if desired_type in item:
            filtered_jsons(jsons_output_directory,output_directory_filtered[index], context_size, index)
            create_sliding_window_for_directory(directory_protocol[index],'.',context_size + 2, protocol_vector[index])
            if dataset_size != 0:
                divide(dataset_size, protocol_vector[index])
                process_files_json2csv(protocol_vector[index])
            else:
                json2csv_1(protocol_vector[index])
    if desired_type == 'all':
        filtered_jsons_all(jsons_output_directory, context_size)
        for index in range(len(directory_protocol)):
            create_sliding_window_for_directory(directory_protocol[index],'.',context_size + 2, protocol_vector[index])
            if dataset_size != 0:
                divide(dataset_size, protocol_vector[index])
                process_files_json2csv(protocol_vector[index])
            else:
                json2csv_1(protocol_vector[index])

    file = '/home/px4/bala/output_filtered_tcp/filtered_comma_capture_35-0004.pcap.json'
    file1 = '/home/px4/bala/output_filtered_mavlink/filtered_comma_capture_1-0005.pcap.json'

    # file = ''.
    # create_sliding_window_2(file,'slidding_window_testing.json',6)
    # update_slidingwindow('slidding_window.json','slidding_window_update.json')
    # finalize_json_og_new(4, 1,file)

    """finalize_json_og(jsons_output_directory, output_directory_filtered[2])
    print("Beginning to filter pcaps, gaining the fields")
    for index, element in enumerate(directory_protocol):
        filtered_jsons(element, output_directory_filtered[index])
    process_directory(1, '.', output_directory_filtered[0])  # directory_protocol[0], output_directory_filtered[0])
    num_cores = 5
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_cores) as executor:
        executor.map(process_directory, range(len(directory_protocol)), directory_protocol, output_directory_filtered)"""
    # combine.py
    # add_na_messages_ijson('/home/px4/bala/output_filtered_mavlink/filtered_capture_1-0005.pcap.json', 'file2.json', 3)
    """for index, element in enumerate(protocol_vector):
        if (index == 1):
            context_size = 4
            output_combined_file = '/home/px4/bala/output_filtered_udp/filtered_array_capture_1-0005.pcap.json' # f'output_combined_today_{protocol_vector[index]}.json' # '/home/px4/bala/output_filtered_udp/filtered_array_capture_1-0005.pcap.json' # '/home/px4/bala/output_filtered_mavlink/filtered_capture_1-0005.pcap.json' # '/home/px4/bala/output_filtered_udp/filtered_comma_capture_1-0005.pcap.json' # f'output_combined{protocol_vector[index]}.json'
            # combine_json_files(output_directory_filtered[index], output_combined_file, context_size + 1)

            # null.py
            finalize_json_og(context_size, index, output_combined_file)"""
    """
    num_processes = os.cpu_count()
    args_list = [(output_directory_filtered[i], protocol_vector[i], i) for i in range(len(protocol_vector))]

    with Pool(num_processes) as pool:
        pool.map(combine_and_finalize_wrapper, args_list)"""
    
