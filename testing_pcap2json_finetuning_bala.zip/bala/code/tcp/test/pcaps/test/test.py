import os
import subprocess

input_directory = "."
output_directory = "."

# Get a list of pcap files in the input directory
pcap_files = [file for file in os.listdir(input_directory) if file.endswith(".pcap")]

for pcap_file in pcap_files:
    # Full path of input pcap file
    check = 1
    protocol_vector = ["tcp", "udp", "mavlink"]
    if all(protocol not in pcap_file for protocol in protocol_vector):
    # if protocol_vector not in pcap_file:
        input_pcap_path = os.path.join(input_directory, pcap_file)

        # Command to run for each pcap file
        command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e tcp.flags"

        # Run the command and capture the output
        result = subprocess.run(command, shell=True, capture_output=True, text=True)

        # Check if the command was successful
        if result.returncode == 0:
            # Access the output as a string
            output_string = result.stdout.strip()

            if output_string:
                # If the output string is not empty, modify the file name
                new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[0]}.pcap"
                print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)
                check = 0

                # Move the original pcap file to the output directory
                output_pcap_path = os.path.join(output_directory, new_file_name)
                os.rename(input_pcap_path, output_pcap_path)
        else:
            # Handle the case where the command failed
            print(f"Error for {pcap_file}:", result.stderr)
            
        if check:      
            command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e mavlink_proto.magic"
            # Run the command and capture the output
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                # Access the output as a string
                output_string = result.stdout.strip()
                if output_string:
                    # If the output string is not empty, modify the file name
                    new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[2]}.pcap"
                    print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)
                    check = 0

                    # Move the original pcap file to the output directory
                    output_pcap_path = os.path.join(output_directory, new_file_name)
                    os.rename(input_pcap_path, output_pcap_path)
            else:
                # Handle the case where the command failed
                print(f"Error for {pcap_file}:", result.stderr)
        if check:
            command = f"tshark -r \"{input_pcap_path}\" -c 1 -T fields -e udp.srcport"
            # Run the command and capture the output
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                # Access the output as a string
                output_string = result.stdout.strip()
                if output_string:
                    # If the output string is not empty, modify the file name
                    new_file_name = f"{os.path.splitext(pcap_file)[0]}_{protocol_vector[1]}.pcap"
                    print(f"Output String is not empty for {pcap_file}. New file name:", new_file_name)

                    # Move the original pcap file to the output directory
                    output_pcap_path = os.path.join(output_directory, new_file_name)
                    os.rename(input_pcap_path, output_pcap_path)
                else:
                    # If the output string is empty, keep the original file name
                    print(f"Output String is empty for {pcap_file}. File name remains unchanged:", pcap_file)
            else:
                # Handle the case where the command failed
                print(f"Error for {pcap_file}:", result.stderr)

