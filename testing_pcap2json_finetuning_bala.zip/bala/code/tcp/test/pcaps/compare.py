from lsh import minhash

file_content = []
for x in range (5):
    with open(f'flags_string_{x}.txt', 'r', encoding='utf-8') as file:
        file_content.append(file.read()
for _ in range(5):
    hasher = minhash.MinHasher(seeds=100, char_ngram=5)
    fingerprint0 = hasher.fingerprint(file_content[0])
    fingerprint1 = hasher.fingerprint(file_content[1])
    print(sum(fingerprint0[i] in fingerprint1 for i in range(hasher.num_seeds)) / hasher.num_seeds)

