import json

# Open and read the JSON data from 'output2.json'
with open('output2.json', 'r') as in_file:
    json_data = json.load(in_file)

# Process each item in the JSON array
for index, item in enumerate(json_data):
    # Check if the 'flags_string' key exists
    if 'flags_string' in item:
        # Create a unique filename for each file
        filename = f"flags_string_{index}.txt"

        # Write the 'flags_string' content to the file
        with open(filename, 'w') as out_file:
            out_file.write(item['flags_string'])

        print(f"'flags_string' from item {index} saved to {filename}")
