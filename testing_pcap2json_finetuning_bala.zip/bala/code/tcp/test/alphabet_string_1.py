import ijson
import json

def unique_alphabet(flags):
    return sorted(set(flags))

def flags_to_string(flags, alphabet):
    return ''.join([str(alphabet.index(flag)) if flag in alphabet else '' for flag in flags])

def shorten_flags_string(flags_string):
    shortened = ''
    prev_char = ''
    for char in flags_string:
        if char == prev_char:
            if shortened[-1] != '*':  # Avoid adding multiple '*' for long sequences
                shortened += '*'
        else:
            shortened += char
        prev_char = char
    return shortened

# Example file paths - replace with actual paths
file_paths = ['../output_filtered_tcp/filtered_comma_capture_91-0003.pcap.json']

all_flags = []
output = []

# Read each file and extract flags using ijson
for path in file_paths:
    file_flags = []
    with open(path, 'rb') as file:
        jsonobj = ijson.items(file, 'item.flags', use_float=True)
        for item in jsonobj:
            if item is not None:
                file_flags.append(item)
    all_flags.extend(file_flags)
    output.append({'file': path, 'flags_string': None, 'flags_string_shorten': None})

# Generate unique alphabet list
alphabet = unique_alphabet(all_flags)

# Convert flags to string for each file and create shortened string
for i, path in enumerate(file_paths):
    file_flags = []
    with open(path, 'rb') as file:
        jsonobj = ijson.items(file, 'item.flags', use_float=True)
        for item in jsonobj:
            if item is not None:
                file_flags.append(item)
    flags_string = flags_to_string(file_flags, alphabet)
    output[i]['flags_string'] = flags_string
    output[i]['flags_string_shorten'] = shorten_flags_string(flags_string)

# Add the alphabet conversion to the output
alphabet_conversion = {flag: i for i, flag in enumerate(alphabet)}
output.append({'alphabet_conversion': alphabet_conversion})

# Save to output JSON
with open('output5.json', 'w') as out_file:
    json.dump(output, out_file, indent=4)

print("Output JSON created with flag strings and shortened strings for each file, and alphabet conversion.")
