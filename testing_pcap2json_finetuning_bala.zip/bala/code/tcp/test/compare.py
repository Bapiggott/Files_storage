from lsh import minhash

file_content = []
for x in range (5):
    with open(f'flags_string_{x}.txt', 'r', encoding='utf-8') as file:
        file_content.append(file.read())

"""for _ in range(5):
    hasher = minhash.MinHasher(seeds=100, char_ngram=5)
    fingerprint0 = hasher.fingerprint(file_content[0])
    fingerprint1 = hasher.fingerprint(file_content[1])
    print(sum(fingerprint0[i] in fingerprint1 for i in range(hasher.num_seeds)) / hasher.num_seeds)

"""
from lsh import minhash

# Initialize MinHasher
hasher = minhash.MinHasher(seeds=100, char_ngram=5)

# Initialize a list to store the similarities
similarities = []

# Compare each file's content with every other file's content
for i in range(5):
    for j in range(i + 1, 5):
        fingerprint1 = hasher.fingerprint(file_content[i].encode('utf8'))
        fingerprint2 = hasher.fingerprint(file_content[j].encode('utf8'))

        similarity = sum(f1 in fingerprint2 for f1 in fingerprint1) / hasher.num_seeds
        similarities.append((f"flags_string_{i}.txt", f"flags_string_{j}.txt", similarity))

# Print or process the similarities
for item in similarities:
    print(f"Similarity between {item[0]} and {item[1]}: {item[2]}")
