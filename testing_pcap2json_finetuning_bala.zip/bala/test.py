import os
import json
import ijson
import re
import time

# Tuned for optimal CPU time
def process_dict_tcp_tuned(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    valid_keys = ['tcp.srcport', 'tcp.dstport', 'tcp.len', 'tcp.seq', 'tcp.ack', 'tcp.flags_tree']
    wanted_key_strings = ["sport", "dport", "len", "seq", "ack", "flags"]

    result[wanted_key_strings[0]] = data_dict[valid_keys[0]]
    result[wanted_key_strings[1]] = data_dict[valid_keys[1]]
    result[wanted_key_strings[2]] = data_dict[valid_keys[2]]
    result[wanted_key_strings[3]] = data_dict[valid_keys[3]]
    result[wanted_key_strings[4]] = data_dict[valid_keys[4]]
    flags_tree = data_dict[valid_keys[5]]
    flags = flags_tree['tcp.flags.str']
    matches = re.findall(r'\b[A-Z]+\b', flags)
    result[wanted_key_strings[5]] = matches[0]

    return result;
    
# collects the data that we want from the item
def process_dict_tcp(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    valid_key_strings = ["srcport", "dstport", "len", "seq", "ack", "str"]
    wanted_key_strings = ["sport", "dport", "len", "seq", "ack", "flags"]
    
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_tcp(value, prefix=full_key, result=result)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            if key_string in valid_key_strings:
                index = valid_key_strings.index(key_string)
                if index == 5:
                    matches = re.findall(r'\b[A-Z]+\b', value)
                    result[wanted_key_strings[5]] = matches[0]
                else:
                    result[wanted_key_strings[index]] = value

    return result

def process_dict_udp(data_dict, prefix='', result=None):
    if result is None:
        result = {}
    for key, value in data_dict.items():
        full_key = f"{prefix}_{key}" if prefix else key

        if isinstance(value, dict):
            process_dict_udp(value, prefix=full_key, result=result)
        else:
            # Extract the portion of the key after the last period
            key_string = key.rsplit('.', 1)[-1]
            if key_string != "payload":
                result[key_string] = value
    print("return from process_dict_udp")
    return result


def filtered_jsons(input_directory, output_directory, chunk_size=100):
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    #filename = 'capture_91-0003.pcap.json'
    filename = 'first2360.json'
    if filename.endswith(".json"):
        input_file_path = os.path.join(input_directory, filename)
        output_file_path = os.path.join(output_directory, f"filtered_{filename}")
        output_file = open(output_file_path, "w")
        with open(input_file_path, 'rb') as file:
            print(input_file_path)
            output_file.write('[\n')
            #filtered_data_list = []
            counter = 0
            try:
                jsonobj = ijson.items(file, 'item._source.layers.tcp', use_float=True)
                print(f'\n\n\n{counter}')
                for item in jsonobj:
                    try:
                        counter += 1
                        print(f'counter:{counter}\n')

                        if counter > 1:
                            output_file.write(',\n')
                        #print(item)
                        mavlink_proto_dict = item # ["_source"]["layers"]["tcp"]

                        # gets the data we want form the item
                        filtered_data = process_dict_tcp_tuned(mavlink_proto_dict)
                        # Write immediately instead of adding to a list and write at the end
                        # Accumulating list will consume lot of memory proportional to the file size
                        json.dump(filtered_data, output_file, indent=4)

                        #filtered_data_list.append(filtered_data)

                    except Exception as ex:
                        print(f'Counter:{counter}\n')
                        print(f"An unexpected error occurred: {ex}")
                        print(item)
                        continue
                #with open(output_file_path, 'a') as output_file:
                    #json.dump(filtered_data_list, output_file, indent=4)
                    #output_file.write('\n')
                    
            except Exception as ex:
                    print(f'Counter:{counter}\n')
                    print(f"An unexpected error occurred: {ex}")
                    print(item)
            output_file.write('\n]')
        

t = time.process_time()

filtered_jsons('./input', './output')

elapsed_time = time.process_time() - t
print(f'elapsed time: {elapsed_time}')

